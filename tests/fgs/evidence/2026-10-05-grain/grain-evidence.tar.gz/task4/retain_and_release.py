"""Preserve bounded native event evidence, then release only owned scored raw.

Explicit parent use after reading the census and inspecting source mask proof.
Original copies, encodes, tables and metrics are never modified.
"""
from pathlib import Path
import argparse, datetime, hashlib, json, zipfile
import numpy as np
import grain_axes as axes
import prepare_instrumentation_windows as native

p=argparse.ArgumentParser();p.add_argument('--folder',type=Path,required=True);p.add_argument('--census',type=Path,required=True);p.add_argument('--review',required=True);a=p.parse_args()
f=a.folder.resolve();root=Path(__file__).resolve().parent
assert f.is_relative_to(root) and len(a.review)>30
receipt=json.loads((f/'execution-receipt.json').read_text());assert receipt['complete']
constant_path=f/'constant-patches-v2/summary.json'
if not constant_path.exists():constant_path=f/'constant-patches/summary.json'
constant=json.loads(constant_path.read_text());assert constant['complete']
assert constant.get('schema')=='fgs-constant-patch-safety/2' or all(v['changed_pixels']==0 for v in constant['counts'].values())
w=json.loads((f/'manifest.reviewed.json').read_text())['windows'][0]
v=json.loads(a.census.read_text())['windows'];c=next(x for x in v if x['id']==w['id'])
assert c['frames']==w['frame_count'] and Path(c['metadata_path'])==f/'metrics/summary.json'
assert hashlib.sha256((f/'metrics/summary.json').read_bytes()).hexdigest()==c['metadata_sha256']
assert hashlib.file_digest((f/'metrics/per-frame.jsonl').open('rb'),'sha256').hexdigest()==c['per_frame_sha256']
assert json.loads((f/'selection/selection.json').read_text())['review']['complete']
centers={e['frame'] for e in constant['max_examples'].values()}
for plane in axes.PLANES:
    events=[b['max_excess'] for b in c['bands'] if b['mask']=='core' and b['plane']==plane and b['max_excess'] and b['max_excess']['added_minus_source_8bit']>0]
    if events:centers.add(max(events,key=lambda e:e['added_minus_source_8bit'])['frame'])
    changes=[x for x in c['largest_source_relative_changes'] if x['mask']=='core' and x['plane']==plane and x['added_change_exceeding_source_change']>0]
    if changes:centers.add(max(changes,key=lambda e:e['added_change_exceeding_source_change'])['to_frame'])
indices=sorted({i for x in centers for i in (x-1,x,x+1) if 0<=i<w['frame_count']})
assert len(indices)<=27
records=[]
for layer,v in receipt['owned_raw_files'].items():
    path=Path(v['path']);assert path.parent==f and path.name==layer+'.yuv' and native.identity(path)==v['stat'];records.append(v)
out=f/'retained-events';out.mkdir(exist_ok=False);data={}
for layer in ('source','base','played'):
    raw=axes.Raw(w[layer],w['width'],w['height'],w['frame_count'])
    for i in indices:
        for plane,values in zip(axes.PLANES,raw.planes(i)):
            data[f'{layer}_{i}_{plane}']=np.rint(values*2**(w[layer]['bits']-8)).astype('uint16')
archive=out/'native-frames.npz';np.savez_compressed(archive,**data)
with zipfile.ZipFile(archive) as z:assert z.testzip() is None
report={'utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'parent_review':a.review,'frames':indices,'selection':'Per-plane core maximum positive amplitude excess and maximum temporal excess, with adjacent frames; diagnostic retention only, no census exclusions','native_bits':{k:w[k]['bits'] for k in ('source','base','played')},'archive_sha256':hashlib.file_digest(archive.open('rb'),'sha256').hexdigest(),'owned_raw_files':records,'released':False}
path=f/'raw-release.json'
with path.open('x') as stream:json.dump(report,stream,indent=2);stream.write('\n')
for v in records:
    assert native.identity(v['path'])==v['stat'];Path(v['path']).unlink()
report['released']=True;path.write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps({'window':w['id'],'retained_frames':indices,'released_owned_raw_bytes':sum(v['stat'][2] for v in records)}))
