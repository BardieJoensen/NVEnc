#!/usr/bin/env python3
"""Bounded, CPU-only grain diagnostics on explicitly aligned native YUV420.

No encoder, decoder, media discovery, resampling, or colour conversion. Source
patches are proposed independently and must be inspected before scoring.
Plane-detrended flat-patch RMS is a grain proxy, not a perfect grain separator.
"""
import argparse
import collections
from fractions import Fraction
import hashlib
import json
import math
from pathlib import Path

import numpy as np

SCHEMA = "fgs-grain-axes/1"
BANDS = [0, 32, 64, 96, 128, 160, 192, 224, 256]
PLANES = ("Y", "Cb", "Cr")
LAYERS = ("source", "played", "base", "added", "raw_base", "removed")
LAGS = ("h1", "h2", "v1", "v2")


def dump(path, value):
    with Path(path).open("x") as stream:
        json.dump(value, stream, indent=2, allow_nan=False)
        stream.write("\n")


def signature(path):
    stat = Path(path).stat()
    return {"path": str(Path(path).resolve()), "bytes": stat.st_size,
            "mtime_ns": stat.st_mtime_ns, "inode": stat.st_ino,
            "device": stat.st_dev}


class Raw:
    def __init__(self, description, width, height, count):
        self.path = Path(description["path"])
        if "/tmp/downloads/codex-work/" not in str(self.path.resolve()):
            raise ValueError("raw input must be an owned codex-work scratch file")
        self.bits = int(description["bits"])
        if self.bits not in (8, 10, 12):
            raise ValueError("only native 8/10/12-bit planar YUV420 is supported")
        self.width, self.height = width, height
        self.frame_samples = width * height * 3 // 2
        dtype = np.dtype("u1" if self.bits == 8 else "<u2")
        expected = self.frame_samples * count * dtype.itemsize
        if expected > 4 * 1024**3 or self.path.stat().st_size != expected:
            raise ValueError("raw file must contain exactly declared frames and be <=4 GiB")
        self.data = np.memmap(self.path, mode="r", dtype=dtype,
                              shape=(count, self.frame_samples))

    def planes(self, index):
        flat = self.data[index]
        size = self.width * self.height
        scale = float(2 ** (self.bits - 8))
        return (flat[:size].reshape(self.height, self.width).astype(np.float32) / scale,
                flat[size:size * 5 // 4].reshape(self.height // 2, self.width // 2).astype(np.float32) / scale,
                flat[size * 5 // 4:].reshape(self.height // 2, self.width // 2).astype(np.float32) / scale)


def residual(patch):
    """Remove an affine plane, using the existing texture harness convention."""
    a = np.asarray(patch, dtype=np.float64)
    height, width = a.shape
    x = np.arange(width, dtype=np.float64) - (width - 1) / 2
    y = np.arange(height, dtype=np.float64) - (height - 1) / 2
    mean = a.mean()
    sx = np.sum(a * x[None, :]) / (height * np.sum(x * x))
    sy = np.sum(a * y[:, None]) / (width * np.sum(y * y))
    return a - mean - sx * x[None, :] - sy * y[:, None]


def moments(patch):
    a = residual(patch)
    energy = float(np.mean(a * a))
    hf = a[1:-1, 1:-1] - (a[:-2, 1:-1] + a[2:, 1:-1]
         + a[1:-1, :-2] + a[1:-1, 2:]) / 4
    # Unit white-noise gain: the cross high-pass has variance gain 1.25.
    high_energy = float(np.var(hf) / 1.25)
    cov = {"h1": float(np.mean(a[:, :-1] * a[:, 1:])),
           "h2": float(np.mean(a[:, :-2] * a[:, 2:])),
           "v1": float(np.mean(a[:-1, :] * a[1:, :])),
           "v2": float(np.mean(a[:-2, :] * a[2:, :]))}
    return {"energy": energy, "hf_energy": high_energy, "covariance": cov}


def structure_score(patch):
    # Block-average the SOURCE before measuring large-scale residual structure.
    # A strict/expanded comparison and actual patch review remain mandatory:
    # coarse grain itself can affect this ranking.
    height, width = patch.shape
    small = patch.reshape(height // 4, 4, width // 4, 4).mean(axis=(1, 3))
    a = residual(small)
    gx = (a[1:-1, 2:] - a[1:-1, :-2]) / 2
    gy = (a[2:, 1:-1] - a[:-2, 1:-1]) / 2
    xx, yy, xy = np.mean(gx * gx), np.mean(gy * gy), np.mean(gx * gy)
    coherence = math.sqrt((xx - yy)**2 + 4 * xy * xy) / max(xx + yy, 1e-12)
    return float(np.std(a) * (1 + coherence))


def load_manifest(path):
    raw = Path(path).read_bytes()
    m = json.loads(raw)
    if m.get("schema") != SCHEMA or not m.get("production_receipt"):
        raise ValueError("manifest needs schema and pinned production receipt")
    if len(m["windows"]) > 16:
        raise ValueError("bounded campaign permits at most 16 explicit windows")
    ids = [w["id"] for w in m["windows"]]
    if len(ids) != len(set(ids)):
        raise ValueError("window IDs must be unique")
    for w in m["windows"]:
        width, height, count = w["width"], w["height"], w["frame_count"]
        if width % 2 or height % 2 or width > 4096 or height > 2160 or count > 720 or count < 3:
            raise ValueError("expected 3..720 aligned frames, even geometry <=4096x2160")
        proof = w.get("alignment", {})
        if not proof.get("metadata") or not proof.get("receipt"):
            raise ValueError("exact source/output frame alignment receipt is required")
        for field in ("title", "content_class", "transfer", "range", "qvbr", "source_sha256"):
            if field not in w:
                raise ValueError("missing window provenance: " + field)
        if not w.get("active_rect_reviewed") or not w.get("active_rect_evidence"):
            raise ValueError("active-picture rectangle needs a bar/crop review receipt")
        x, y, cw, ch = w["active_rect"]
        if min(x, y) < 0 or min(cw, ch) < 32 or any(v % 2 for v in (x, y, cw, ch)):
            raise ValueError("invalid even active-picture rectangle")
        if x + cw > width or y + ch > height:
            raise ValueError("active-picture rectangle extends past frame")
        indices = w["sample_frames"]
        if len(indices) < 3 or len(indices) > 720 or sorted(set(indices)) != indices:
            raise ValueError("supply 3..720 unique sorted sample frames; temporal work should include every frame")
        if min(indices) < 0 or max(indices) >= count:
            raise ValueError("sample frame outside raw window")
    return m, hashlib.sha256(raw).hexdigest()


def propose(manifest_path, output):
    manifest, digest = load_manifest(manifest_path)
    result = {"schema": SCHEMA, "manifest_sha256": digest,
              "review": {"complete": False, "receipt": None, "excluded": []},
              "warning": "Proposed source patches require inspection for bars/off-picture and structure; legitimate flat fills are primary clean-safety evidence, not natural-grain fit data. No output pixels selected them.",
              "windows": []}
    for w in manifest["windows"]:
        src = Raw(w["source"], w["width"], w["height"], w["frame_count"])
        x0, y0, cw, ch = w["active_rect"]
        occupancy = np.zeros(8, dtype=np.int64)
        rows = []
        for frame in w["sample_frames"]:
            planes = src.planes(frame)
            active = planes[0][y0:y0 + ch, x0:x0 + cw]
            occupancy += np.histogram(active, BANDS)[0]
            for y in range(y0, y0 + ch - 31, 32):
                for x in range(x0, x0 + cw - 31, 32):
                    patches = [planes[0][y:y + 32, x:x + 32]]
                    patches += [p[y // 2:y // 2 + 16, x // 2:x // 2 + 16] for p in planes[1:]]
                    mean = float(patches[0].mean())
                    band = int(np.clip(np.searchsorted(BANDS, mean, side="right") - 1, 0, 7))
                    structure = [structure_score(p) for p in patches]
                    rows.append({"frame": frame, "x": x, "y": y, "band": band,
                                 "source_y_mean": mean, "score": max(structure),
                                 "structure_by_plane": structure,
                                 "source_sigma": [math.sqrt(moments(p)["energy"]) for p in patches],
                                 "masks": []})
        thresholds = {}
        for band in range(8):
            candidates = [r for r in rows if r["band"] == band]
            if not candidates:
                continue
            thresholds[str(band)] = {}
            for name, percentile in (("core", 25), ("expanded", 60)):
                threshold = float(np.percentile([r["score"] for r in candidates], percentile))
                thresholds[str(band)][name] = threshold
                for row in candidates:
                    if row["score"] <= threshold:
                        row["masks"].append(name)
        result["windows"].append({"id": w["id"], "source_raw_stat": signature(src.path),
            "active_pixels_by_band": occupancy.tolist(),
            "active_pixels": int(occupancy.sum()), "thresholds": thresholds,
            "patches": [r for r in rows if r["masks"]],
            "all_grid_patches": len(rows)})
    dump(output, result)


def combine(records, floor):
    energy = float(np.mean([r["energy"] for r in records]))
    return {"amplitude_sigma_8bit": math.sqrt(energy),
            "hf_sigma_8bit": math.sqrt(float(np.mean([r["hf_energy"] for r in records]))),
            "acf": {lag: float(np.mean([r["covariance"][lag] for r in records])) / energy
                    if energy >= floor * floor else None for lag in LAGS}}


def comparison(layers, floor):
    source, played = layers["source"], layers["played"]
    answer = {}
    for name in ("amplitude_sigma_8bit", "hf_sigma_8bit"):
        a, b = source[name], played[name]
        answer[name] = {"delta": b - a, "ratio": b / a if a >= floor else None}
    answer["acf_delta"] = {lag: played["acf"][lag] - source["acf"][lag]
        if source["acf"][lag] is not None and played["acf"][lag] is not None else None for lag in LAGS}
    return answer


def exact_added_moments(pixels):
    """Actual grain-on minus grain-off values: never apply a reporting floor."""
    a = np.asarray(pixels, dtype=np.float64)
    return dict(pixels=a.size, nonzero_pixels=int(np.count_nonzero(a)),
                squared_sum=float(np.sum(a*a)), absolute_sum=float(np.sum(np.abs(a))),
                signed_sum=float(np.sum(a)), maximum_absolute=float(np.max(np.abs(a))))


def combine_exact_added(rows):
    count = sum(r['pixels'] for r in rows)
    nonzero = sum(r['nonzero_pixels'] for r in rows)
    return dict(sampled_pixels=count, nonzero_pixels=nonzero,
        nonzero_fraction=nonzero/count, any_nonzero=bool(nonzero),
        absolute_rms_8bit=math.sqrt(sum(r['squared_sum'] for r in rows)/count),
        mean_absolute_8bit=sum(r['absolute_sum'] for r in rows)/count,
        signed_mean_8bit=sum(r['signed_sum'] for r in rows)/count,
        maximum_absolute_8bit=max(r['maximum_absolute'] for r in rows))


def temporal_changes(frame_bands):
    """Descriptive source-relative changes, not a calibrated flicker alarm."""
    groups = collections.defaultdict(list)
    for row in frame_bands:
        if row['patches'] >= 8:
            groups[(row['mask'],row['plane'],tuple(row['band']))].append(row)
    changes = []
    for (mask,plane,band),rows in groups.items():
        for a,b in zip(rows,rows[1:]):
            def delta(layer):
                return b['layers'][layer]['amplitude_sigma_8bit']-a['layers'][layer]['amplitude_sigma_8bit']
            ds,dp,db = delta('source'),delta('played'),delta('base')
            dg=b['exact_added']['absolute_rms_8bit']-a['exact_added']['absolute_rms_8bit']
            changes.append(dict(mask=mask,plane=plane,band=list(band),
                from_frame=a['frame'],to_frame=b['frame'],source_change=ds,played_change=dp,
                decoded_base_change=db,added_absolute_rms_change=dg,
                added_change_exceeding_source_change=max(0.0,abs(dg)-abs(ds)),
                played_change_minus_source_change=dp-ds,
                source_added_directions_disagree=bool(ds*dg<0),
                source_occupancy_change=b['occupancy']-a['occupancy'],
                same_patch_coordinates=a['coordinates_sha256']==b['coordinates_sha256'],
                interpretation='Review source trend, mask/occupancy change and the noise-floor controls before calling this flicker; no automatic defect threshold.'))
    return sorted(changes,key=lambda r:r['added_change_exceeding_source_change'],reverse=True)


def score(manifest_path, selection_path, output):
    manifest, digest = load_manifest(manifest_path)
    selection = json.loads(Path(selection_path).read_text())
    if selection["manifest_sha256"] != digest or not selection["review"]["complete"] or not selection["review"]["receipt"]:
        raise ValueError("matching manifest and an actual completed mask review are required")
    floor = float(manifest.get("ratio_floor_8bit", 0.25))
    if floor <= 0:
        raise ValueError("positive reporting floor required; never form near-zero ratios")
    # Exclusion tuples are [window_id, frame, x, y], selected from source review.
    excluded = {tuple(x) for x in selection["review"]["excluded"]}
    result = {"schema": SCHEMA, "manifest_sha256": digest, "ratio_floor_8bit": floor,
        "estimator": "plane-detrended native flat-patch RMS; cross high-pass divided by sqrt(1.25); energy-weighted directional ACF",
        "limits": "conditional flat-patch grain proxies, not a clean-source oracle; chroma lag is in native chroma pixels; no HDR/SDR pooling",
        "selection_review": selection["review"], "windows": [], "response_samples": [],
        "clean_safety_priority": "Legitimate flat fills are primary clean-source safety evidence. Exact added RMS/nonzero fractions are never hidden by the source ratio floor; source-clean classification remains a separate uncertainty."}
    selections = {w["id"]: w for w in selection["windows"]}
    for w in manifest["windows"]:
        pick = selections[w["id"]]
        if signature(w["source"]["path"]) != pick["source_raw_stat"]:
            raise ValueError("source raw file changed after selection")
        raw = {name: Raw(w[name], w["width"], w["height"], w["frame_count"])
               for name in ("source", "played", "base", "raw_base") if name in w}
        if not all(name in raw for name in ("source", "played", "base")):
            raise ValueError("source, grain-on played, and SAME BITSTREAM grain-off base required")
        alignment = json.loads(Path(w["alignment"]["receipt"]).read_text())
        if alignment.get("manifest_sha256") != digest:
            raise ValueError("alignment receipt does not bind this exact manifest")
        checks = {x["id"]: x for x in alignment["windows"]}
        check = checks.get(w["id"], {})
        if check.get("status") != "pass":
            raise ValueError("window alignment is unverified or inconclusive")
        if check["metadata_sha256"] != hashlib.sha256(Path(w["alignment"]["metadata"]).read_bytes()).hexdigest():
            raise ValueError("alignment metadata changed after verification")
        if check["raw_stats"] != {n: signature(r.path) for n, r in raw.items()}:
            raise ValueError("raw window changed after alignment verification")
        timing_metadata = json.loads(Path(w['alignment']['metadata']).read_text())
        source_pts = timing_metadata.get('frame_pts',{}).get('source',timing_metadata.get('source_pts'))
        if source_pts is not None and len(source_pts) != w['frame_count']:
            raise ValueError('Source timestamp count differs from raw window')
        accum = collections.defaultdict(lambda: collections.defaultdict(list))
        exact = collections.defaultdict(list)
        per_frame = collections.defaultdict(lambda: collections.defaultdict(list))
        frame_exact = collections.defaultdict(list)
        frame_coordinates = collections.defaultdict(list)
        frame_occupancy = {}
        frames = collections.defaultdict(set)
        counts = collections.Counter()
        for frame in w["sample_frames"]:
            arrays = {name: reader.planes(frame) for name, reader in raw.items()}
            x0,y0,cw,ch = w['active_rect']
            frame_hist = np.histogram(arrays['source'][0][y0:y0+ch,x0:x0+cw],BANDS)[0]
            frame_occupancy[frame] = frame_hist.astype(np.float64)/frame_hist.sum()
            for row in (r for r in pick["patches"] if r["frame"] == frame):
                if (w["id"], frame, row["x"], row["y"]) in excluded:
                    continue
                for plane, label in enumerate(PLANES):
                    factor = 1 if plane == 0 else 2
                    x, y, size = row["x"] // factor, row["y"] // factor, 32 // factor
                    patches = {name: p[plane][y:y + size, x:x + size] for name, p in arrays.items()}
                    patches["added"] = patches["played"] - patches["base"]
                    if "raw_base" in patches:
                        patches["removed"] = patches["source"] - patches["raw_base"]
                    measured = {name: moments(p) for name, p in patches.items()}
                    actual_added = exact_added_moments(patches['added'])
                    for mask in row["masks"]:
                        key = (mask, label, row["band"])
                        frame_key = (frame,mask,label,row['band'])
                        counts[key] += 1
                        frames[key].add(frame)
                        exact[key].append(actual_added)
                        frame_exact[frame_key].append(actual_added)
                        frame_coordinates[frame_key].append((row['x'],row['y']))
                        for name, measurement in measured.items():
                            accum[key][name].append(measurement)
                            per_frame[frame_key][name].append(measurement)
        report = {"id": w["id"], "title": w["title"], "content_class": w["content_class"],
            "transfer": w["transfer"], "range": w["range"], "qvbr": w["qvbr"],
            "input_stats": {n: signature(r.path) for n, r in raw.items()},
            "source_sha256": w["source_sha256"], "active_rect": w["active_rect"],
            "selected_patch_pixels_are_conditional": True, "bands": [], "weighted": [],
            "per_frame_bands": [], "per_frame_weighted": []}
        occupancy = np.asarray(pick["active_pixels_by_band"], dtype=np.float64) / pick["active_pixels"]
        report["source_active_pixels_by_band"] = pick["active_pixels_by_band"]
        report["source_active_pixels"] = pick["active_pixels"]
        report["reviewed_selection"] = {mask: {
            "patches": sum(counts[(mask, "Y", band)] for band in range(8)),
            "active_picture_fraction": sum(counts[(mask, "Y", band)] for band in range(8)) * 32 * 32 / pick["active_pixels"]}
            for mask in ("core", "expanded")}
        for mask in ("core", "expanded"):
            for plane in PLANES:
                valid = []
                for band in range(8):
                    key = mask, plane, band
                    item = {"mask": mask, "plane": plane, "band": [BANDS[band], BANDS[band + 1]],
                        "occupancy": float(occupancy[band]), "patches": counts[key],
                        "frames": len(frames[key]), "status": "insufficient"}
                    if exact[key]:
                        item['exact_added'] = combine_exact_added(exact[key])
                    if counts[key] >= 32 and len(frames[key]) >= 3:
                        layers = {name: combine(rows, floor) for name, rows in accum[key].items()}
                        item.update(status="measured", layers=layers, error=comparison(layers, floor))
                        item["source_near_clean"] = layers["source"]["amplitude_sigma_8bit"] < floor
                        valid.append(item)
                        if mask == "core":
                            result["response_samples"].append({"window": w["id"], "title": w["title"],
                                "plane": plane, "band": band, "transfer": w["transfer"],
                                "qvbr": w["qvbr"], "content_class": w["content_class"],
                                "occupancy": float(occupancy[band]),
                                "source": layers["source"]["amplitude_sigma_8bit"],
                                "played": layers["played"]["amplitude_sigma_8bit"],
                                "source_hf": layers["source"]["hf_sigma_8bit"],
                                "played_hf": layers["played"]["hf_sigma_8bit"]})
                    report["bands"].append(item)
                summary = {"mask": mask, "plane": plane,
                    "measured_band_occupancy": sum(v["occupancy"] for v in valid),
                    "note": "weighted errors are conditional on measured bands; unmeasured bands are not zero error"}
                added_bands=[v for v in report['bands'] if v['mask']==mask and v['plane']==plane and 'exact_added' in v]
                added_weight=sum(v['occupancy'] for v in added_bands)
                if added_weight:
                    summary['exact_added']=dict(measured_band_occupancy=added_weight,
                        occupancy_weighted_absolute_rms_8bit=math.sqrt(sum(v['occupancy']*v['exact_added']['absolute_rms_8bit']**2 for v in added_bands)/added_weight),
                        occupancy_weighted_nonzero_fraction=sum(v['occupancy']*v['exact_added']['nonzero_fraction'] for v in added_bands)/added_weight,
                        selected_nonzero_pixels=sum(v['exact_added']['nonzero_pixels'] for v in added_bands),
                        selected_pixels=sum(v['exact_added']['sampled_pixels'] for v in added_bands),
                        reporting_floor_applied=False)
                for metric in ("amplitude_sigma_8bit", "hf_sigma_8bit"):
                    values = [v for v in valid if v["error"][metric]["ratio"] is not None]
                    weight = sum(v["occupancy"] for v in values)
                    summary[metric] = {"ratio_eligible_occupancy": weight,
                        "weighted_absolute_relative_error": sum(v["occupancy"] * abs(v["error"][metric]["ratio"] - 1) for v in values) / weight if weight else None,
                        "weighted_signed_delta": sum(v["occupancy"] * v["error"][metric]["delta"] for v in valid) / summary["measured_band_occupancy"] if valid else None}
                for lag in LAGS:
                    values = [v for v in valid if v["error"]["acf_delta"][lag] is not None]
                    weight = sum(v["occupancy"] for v in values)
                    summary[lag] = {"eligible_occupancy": weight,
                        "weighted_absolute_delta": sum(v["occupancy"] * abs(v["error"]["acf_delta"][lag]) for v in values) / weight if weight else None}
                report["weighted"].append(summary)
        for (frame,mask,plane,band),layers in sorted(per_frame.items()):
            key=(frame,mask,plane,band)
            combined={name:combine(rows,floor) for name,rows in layers.items()}
            report['per_frame_bands'].append(dict(frame=frame,
                source_time_seconds=float(Fraction(source_pts[frame])) if source_pts is not None else None,
                mask=mask,plane=plane,
                band=[BANDS[band],BANDS[band+1]],occupancy=float(frame_occupancy[frame][band]),
                patches=len(layers['source']),
                status='measured' if len(layers['source'])>=8 else 'limited_sampling',
                coordinates_sha256=hashlib.sha256(json.dumps(sorted(frame_coordinates[key])).encode()).hexdigest(),
                layers=combined,error=comparison(combined,floor),
                exact_added=combine_exact_added(frame_exact[key]),
                source_below_ratio_reporting_floor=combined['source']['amplitude_sigma_8bit']<floor,
                source_clean_uncertainty='Flat-patch amplitude proxy; a low source estimate is distinct from proof of no grain. Known fills/zero controls and absolute added pixels provide independent evidence.'))
        for frame in w['sample_frames']:
            for mask in ('core','expanded'):
                for plane in PLANES:
                    rows=[r for r in report['per_frame_bands'] if r['frame']==frame and r['mask']==mask and r['plane']==plane]
                    weight=sum(r['occupancy'] for r in rows)
                    if not weight: continue
                    item=dict(frame=frame,mask=mask,plane=plane,measured_band_occupancy=weight,
                        exact_added_occupancy_weighted_rms_8bit=math.sqrt(sum(r['occupancy']*r['exact_added']['absolute_rms_8bit']**2 for r in rows)/weight),
                        exact_added_occupancy_weighted_nonzero_fraction=sum(r['occupancy']*r['exact_added']['nonzero_fraction'] for r in rows)/weight,
                        exact_added_selected_nonzero_pixels=sum(r['exact_added']['nonzero_pixels'] for r in rows),
                        selected_pixels=sum(r['exact_added']['sampled_pixels'] for r in rows),
                        note='Occupancy-weighted conditional flat-patch statistics, not a whole-picture pixel count; no amplitude/ratio floor applied to added grain')
                    for layer in ('source','played','base'):
                        item[layer+'_occupancy_weighted_sigma_8bit']=math.sqrt(sum(r['occupancy']*r['layers'][layer]['amplitude_sigma_8bit']**2 for r in rows)/weight)
                    report['per_frame_weighted'].append(item)
        report['temporal_changes']=temporal_changes(report['per_frame_bands'])
        report['temporal_scope']=dict(sampled_frames=w['sample_frames'],
            every_frame_measured=w['sample_frames']==list(range(w['frame_count'])),
            caveat='Subsampled frames can miss alternating-frame flicker; temporal diagnosis requires every displayed frame and checking source trends/patch membership.')
        result["windows"].append(report)
    result["response_fit"] = fit_response(result["response_samples"], floor)
    dump(output, result)


def fit_response(samples, floor):
    """Descriptive within-title/band slope; no fictitious pixel-level CI."""
    reports = []
    for plane in PLANES:
        for transfer in sorted({s["transfer"] for s in samples}):
            for metric, source_key, played_key in (("amplitude", "source", "played"),
                                                    ("hf_sigma", "source_hf", "played_hf")):
                groups = collections.defaultdict(list)
                for s in samples:
                    if (s["plane"] == plane and s["transfer"] == transfer
                        and s["content_class"] != "animation-control"
                        and s[source_key] >= floor and s[played_key] > 0):
                        groups[(s["title"], s["qvbr"], s["band"])].append(s)
                admitted = []
                for key, rows in groups.items():
                    # Three distinct windows and useful range, not 3 pixels.
                    if len({r["window"] for r in rows}) < 3:
                        continue
                    x = np.log([r[source_key] for r in rows])
                    y = np.log([r[played_key] for r in rows])
                    if np.ptp(x) < math.log(1.5):
                        continue
                    weights = np.asarray([r["occupancy"] for r in rows], dtype=np.float64)
                    weights /= weights.sum()
                    x -= np.dot(weights, x)
                    y -= np.dot(weights, y)
                    numerator = float(np.dot(weights, x * y))
                    denominator = float(np.dot(weights, x * x))
                    admitted.append({"title": key[0], "qvbr": key[1], "band": key[2],
                        "windows": len(rows), "beta": numerator / denominator,
                        "numerator": numerator, "denominator": denominator,
                        "band_weight": float(np.mean([r["occupancy"] for r in rows])),
                        "played_below_reporting_floor": sum(r[played_key] < floor for r in rows)})
                # Occupancy weights within each title; each admitted title gets
                # equal total weight, never masquerading as library prevalence.
                totals = collections.defaultdict(float)
                for a in admitted:
                    totals[a["title"]] += a["band_weight"]
                def estimate(exclude=None):
                    rows = [a for a in admitted if a["title"] != exclude]
                    num = sum(a["numerator"] * a["band_weight"] / totals[a["title"]] for a in rows)
                    den = sum(a["denominator"] * a["band_weight"] / totals[a["title"]] for a in rows)
                    return num / den if den > 0 else None
                reports.append({"plane": plane, "transfer": transfer, "metric": metric,
                    "beta": estimate(), "strata": admitted, "confidence_interval": None,
                    "leave_one_title_out": {title: estimate(title) for title in totals} if len(totals) >= 3 else None,
                    "interpretation": "descriptive within-title/band slope only; source-floor exclusion, few titles, mask bias and measurement error prevent a library-wide exponent claim; confirm with fixed-texture amplitude-only controls"})
    return reports


def self_test(output):
    rng = np.random.default_rng(20261005)
    noise = rng.normal(size=(256, 256))
    patches = [noise[y:y + 32, x:x + 32] for y in range(0, 256, 32) for x in range(0, 256, 32)]
    ref = combine([moments(p) for p in patches], 1e-9)
    checks = []
    for gain in (0.5, 1.0, 1.5):
        result = combine([moments(gain * p) for p in patches], 1e-9)
        ar = result["amplitude_sigma_8bit"] / ref["amplitude_sigma_8bit"]
        hr = result["hf_sigma_8bit"] / ref["hf_sigma_8bit"]
        ac = max(abs(result["acf"][lag] - ref["acf"][lag]) for lag in LAGS)
        assert abs(ar - gain) < 1e-12 and abs(hr - gain) < 1e-12 and ac < 1e-12
        checks.append({"control": "fixed-texture amplitude gain", "gain": gain,
                       "amplitude_ratio": ar, "hf_ratio": hr, "max_acf_delta": ac})
    coarse = (noise + np.roll(noise, 1, 0) + np.roll(noise, -1, 0)
              + np.roll(noise, 1, 1) + np.roll(noise, -1, 1)) / 5
    cp = [coarse[y:y + 32, x:x + 32] for y in range(0, 256, 32) for x in range(0, 256, 32)]
    before = combine([moments(p) for p in cp], 1e-9)
    gain = ref["amplitude_sigma_8bit"] / before["amplitude_sigma_8bit"]
    changed = combine([moments(gain * p) for p in cp], 1e-9)
    ar = changed["amplitude_sigma_8bit"] / ref["amplitude_sigma_8bit"]
    hr = changed["hf_sigma_8bit"] / ref["hf_sigma_8bit"]
    assert abs(ar - 1) < 1e-12 and hr < 0.95
    assert min(changed["acf"][lag] - ref["acf"][lag] for lag in LAGS) > 0.1
    checks.append({"control": "grain size at fixed detrended RMS", "amplitude_ratio": ar,
                   "hf_ratio": hr, "reference_acf": ref["acf"], "coarse_acf": changed["acf"]})
    # Native-code normalization is shared across planes; this verifies a shift,
    # not a gray16 conversion or a studio/full-range remapping.
    sample8 = rng.integers(0, 256, size=(32, 32)).astype(np.float32)
    assert np.array_equal(sample8, (sample8 * 4) / 4)
    checks.append({"control": "native 8 to 10-bit shift", "max_error": 0})
    zero = combine([moments(np.full((32, 32), 128.0))], 0.25)
    assert zero["amplitude_sigma_8bit"] == 0 and all(v is None for v in zero["acf"].values())
    checks.append({"control": "constant fill", "amplitude": 0, "acf": "not measurable; no zero-energy ratio"})
    dump(output, {"schema": SCHEMA, "status": "pass", "media_read": False,
                  "gpu_used": False, "checks": checks})


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    sub = parser.add_subparsers(dest="mode", required=True)
    for name in ("select", "score"):
        command = sub.add_parser(name)
        command.add_argument("--manifest", required=True)
        command.add_argument("--output", required=True)
        if name == "score":
            command.add_argument("--selection", required=True)
    command = sub.add_parser("self-test")
    command.add_argument("--output", required=True)
    args = parser.parse_args()
    if args.mode == "select":
        propose(args.manifest, args.output)
    elif args.mode == "score":
        score(args.manifest, args.selection, args.output)
    else:
        self_test(args.output)


if __name__ == "__main__":
    main()
