#!/usr/bin/env python3
"""Source-only masks and streaming per-frame native grain measurements.

One frozen window at a time; no encode/decode, media discovery or image resize.
Flat fills are clean-safety evidence. Ratios may be unavailable, actual added
pixels never are. Run select, inspect source-mask proof, then score.
"""
import argparse
from fractions import Fraction
import hashlib
import json
import math
from pathlib import Path

import numpy as np
import grain_axes as axes


def load(path):
    manifest,digest=axes.load_manifest(path)
    if len(manifest['windows'])!=1: raise ValueError('Use one frozen window manifest at a time')
    w=manifest['windows'][0]
    if w['sample_frames']!=list(range(w['frame_count'])):
        raise ValueError('Safety/temporal measurements require every displayed frame')
    budget=sum(Path(w[n]['path']).stat().st_size for n in ('source','played','base') if Path(w[n]['path']).exists())
    if budget>12*(1<<30): raise ValueError('Window raw inputs exceed12GiB')
    return manifest,digest,w


def patches(image,size):
    rows,columns=image.shape[0]//size,image.shape[1]//size
    return image[:rows*size,:columns*size].reshape(rows,size,columns,size).transpose(0,2,1,3).reshape(-1,size,size)


def residual(blocks):
    b=np.asarray(blocks,dtype=np.float64)
    size=b.shape[-1];c=np.arange(size,dtype=np.float64)-(size-1)/2
    norm=size*np.sum(c*c)
    return b-b.mean(axis=(-2,-1),keepdims=True)-np.sum(b*c[None,None,:],axis=(-2,-1))[:,None,None]*c[None,None,:]/norm-np.sum(b*c[None,:,None],axis=(-2,-1))[:,None,None]*c[None,:,None]/norm


def moments(blocks):
    a=residual(blocks)
    high=a[:,1:-1,1:-1]-(a[:,:-2,1:-1]+a[:,2:,1:-1]+a[:,1:-1,:-2]+a[:,1:-1,2:])/4
    return dict(energy=np.mean(a*a,axis=(-2,-1)),hf=np.var(high,axis=(-2,-1))/1.25,
        h1=np.mean(a[:,:,:-1]*a[:,:,1:],axis=(-2,-1)),h2=np.mean(a[:,:,:-2]*a[:,:,2:],axis=(-2,-1)),
        v1=np.mean(a[:,:-1,:]*a[:,1:,:],axis=(-2,-1)),v2=np.mean(a[:,:-2,:]*a[:,2:,:],axis=(-2,-1)))


def structure(blocks):
    size=blocks.shape[-1];n=size//4
    small=blocks.reshape(-1,n,4,n,4).mean(axis=(2,4));a=residual(small)
    gx=(a[:,1:-1,2:]-a[:,1:-1,:-2])/2;gy=(a[:,2:,1:-1]-a[:,:-2,1:-1])/2
    xx=np.mean(gx*gx,axis=(-2,-1));yy=np.mean(gy*gy,axis=(-2,-1));xy=np.mean(gx*gy,axis=(-2,-1))
    coherence=np.sqrt((xx-yy)**2+4*xy*xy)/np.maximum(xx+yy,1e-12)
    return np.std(a,axis=(-2,-1))*(1+coherence)


def window_blocks(planes,rect):
    x,y,width,height=rect
    # Truncate both grids by the same luma32px extent, preserving co-siting.
    width=width//32*32;height=height//32*32
    return [patches(p[y//f:(y+height)//f,x//f:(x+width)//f],32//f)
            for p,f in zip(planes,(1,2,2))]


def select(manifest_path,output):
    manifest,digest,w=load(manifest_path)
    output=Path(output);output.mkdir(parents=True,exist_ok=False)
    src=axes.Raw(w['source'],w['width'],w['height'],w['frame_count'])
    masks=[];bands=[];means=[];occupancy=[]
    for frame in w['sample_frames']:
        planes=src.planes(frame);blocks=window_blocks(planes,w['active_rect'])
        mean=blocks[0].mean(axis=(-2,-1));band=np.clip(np.searchsorted(axes.BANDS,mean,side='right')-1,0,7).astype('u1')
        score=np.max(np.stack([structure(b) for b in blocks]),axis=0)
        chosen=np.zeros(len(mean),dtype='u1')
        for index in range(8):
            eligible=band==index
            if not eligible.any(): continue
            for bit,percentile in ((1,25),(2,60)):
                threshold=np.percentile(score[eligible],percentile)
                chosen[eligible&(score<=threshold)]|=bit
        x,y,width,height=w['active_rect']
        hist=np.histogram(planes[0][y:y+height,x:x+width],axes.BANDS)[0]
        masks.append(chosen);bands.append(band);means.append(mean);occupancy.append(hist)
    np.savez_compressed(output/'source-mask.npz',mask=np.stack(masks),band=np.stack(bands),
        luma_mean=np.stack(means),occupancy=np.stack(occupancy))
    axes.dump(output/'selection.json',dict(schema='fgs-frame-safety-selection/1',manifest_sha256=digest,
        source_raw_stat=axes.signature(w['source']['path']),proof_sha256=hashlib.sha256((output/'source-mask.npz').read_bytes()).hexdigest(),
        active_rect=w['active_rect'],luma_block_size=32,chroma_block_size=16,
        grid_rows=w['active_rect'][3]//32,grid_columns=w['active_rect'][2]//32,
        masks=dict(core=1,expanded=2),frames=w['frame_count'],
        review=dict(complete=False,receipt=None),
        interpretation='Source-only per-band structure selection; legitimate flat animation fills remain eligible. Inspect actual source patches; bars/off-picture must be removed by the active rectangle.'))


def combine(stat,mask,floor):
    e=float(np.mean(stat['energy'][mask]))
    return dict(amplitude_sigma_8bit=math.sqrt(max(0,e)),hf_sigma_8bit=math.sqrt(max(0,float(np.mean(stat['hf'][mask])))),
        acf={k:float(np.mean(stat[k][mask]))/e if e>=floor*floor else None for k in axes.LAGS})


def added_stats(blocks):
    a=np.asarray(blocks,dtype=np.float64)
    return dict(energy=np.mean(a*a,axis=(-2,-1)),nonzero=np.count_nonzero(a,axis=(-2,-1)),
        mean=np.mean(a,axis=(-2,-1)),mean_abs=np.mean(np.abs(a),axis=(-2,-1)),maximum=np.max(np.abs(a),axis=(-2,-1)),pixels=a.shape[-1]**2)


def combine_added(a,mask):
    n=int(mask.sum())*a['pixels'];nz=int(np.sum(a['nonzero'][mask]))
    return dict(absolute_rms_8bit=math.sqrt(float(np.mean(a['energy'][mask]))),
        nonzero_pixels=nz,sampled_pixels=n,nonzero_fraction=nz/n,any_nonzero=bool(nz),
        signed_mean_8bit=float(np.mean(a['mean'][mask])),mean_absolute_8bit=float(np.mean(a['mean_abs'][mask])),
        maximum_absolute_8bit=float(np.max(a['maximum'][mask])),reporting_floor_applied=False)


# Conservative source-only stationary-patch diagnostics, in 8-bit-equivalent
# code units. These are explicit eligibility limits, not quality pass gates.
STATIONARY_MEAN_LIMIT = .25
STATIONARY_LOW_FREQUENCY_RMS_LIMIT = .5


def temporal_stats(source, previous_source, added, previous_added):
    output=[]
    for current,old,grain,old_grain in zip(source,previous_source,added,previous_added):
        delta=current-old;grain_delta=grain-old_grain
        size=delta.shape[-1];n=size//4
        low=delta.reshape(-1,n,4,n,4).mean(axis=(2,4))
        mean=np.mean(delta,axis=(-2,-1))
        low_rms=np.sqrt(np.mean(low*low,axis=(-2,-1)))
        output.append(dict(eligible=(np.abs(mean)<=STATIONARY_MEAN_LIMIT)&
            (low_rms<=STATIONARY_LOW_FREQUENCY_RMS_LIMIT),
            source_difference_variance=np.var(delta,axis=(-2,-1)),
            added_difference_variance=np.var(grain_delta,axis=(-2,-1)),
            source_difference_energy=np.mean(delta*delta,axis=(-2,-1)),
            source_changed_pixels=np.count_nonzero(delta,axis=(-2,-1)),
            source_mean_change=mean,source_low_frequency_difference_rms=low_rms,
            pixels=size*size))
    # A chroma patch is stationary only when its co-sited luma also qualifies.
    for plane in output[1:]: plane['eligible'] &= output[0]['eligible']
    return output


def stationary_summary(t,common,source_stats,current_added):
    common_count=int(common.sum());eligible=common&t['eligible'];count=int(eligible.sum())
    item=dict(common_selected_patches=common_count,stationary_patches=count,
        stationary_fraction_of_common_selected_patches=count/common_count if common_count else None,
        rejected_or_moving_patches=common_count-count,
        status='measured' if count>=8 else 'limited_sampling' if count else 'ineligible',
        source_only_mean_limit_8bit=STATIONARY_MEAN_LIMIT,
        source_only_low_frequency_rms_limit_8bit=STATIONARY_LOW_FREQUENCY_RMS_LIMIT)
    if not count: return item
    pixels=count*t['pixels'];changed=int(np.sum(t['source_changed_pixels'][eligible]))
    item.update(source_temporal_residual_sigma_div_sqrt2_8bit=math.sqrt(float(np.mean(t['source_difference_variance'][eligible]))/2),
        added_temporal_residual_sigma_div_sqrt2_8bit=math.sqrt(float(np.mean(t['added_difference_variance'][eligible]))/2),
        source_difference_absolute_rms_8bit=math.sqrt(float(np.mean(t['source_difference_energy'][eligible]))),
        source_changed_pixels=changed,sampled_pixels=pixels,source_changed_pixel_fraction=changed/pixels,
        exactly_unchanged_source_pixels=pixels-changed,
        source_spatial_residual_sigma_8bit=math.sqrt(float(np.mean(source_stats['energy'][eligible]))),
        exact_added=combine_added(current_added,eligible))
    return item


def score(manifest_path,selection_dir,output):
    manifest,digest,w=load(manifest_path);selection_dir=Path(selection_dir);output=Path(output)
    review=json.loads((selection_dir/'selection.json').read_text())
    if review['manifest_sha256']!=digest or not review['review']['complete'] or not review['review']['receipt']:
        raise ValueError('Actual source-mask review and matching frozen manifest required')
    if review['source_raw_stat']!=axes.signature(w['source']['path']): raise ValueError('Source changed')
    if review['proof_sha256']!=hashlib.sha256((selection_dir/'source-mask.npz').read_bytes()).hexdigest(): raise ValueError('Mask proof changed')
    alignment=json.loads(Path(w['alignment']['receipt']).read_text());check=next(r for r in alignment['windows'] if r['id']==w['id'])
    raw={n:axes.Raw(w[n],w['width'],w['height'],w['frame_count']) for n in ('source','played','base')}
    if alignment['manifest_sha256']!=digest or check['status']!='pass' or check['raw_stats']!={n:axes.signature(r.path) for n,r in raw.items()}:
        raise ValueError('Missing matching checked frame alignment')
    timing_blob=Path(w['alignment']['metadata']).read_bytes()
    if check['metadata_sha256']!=hashlib.sha256(timing_blob).hexdigest(): raise ValueError('Alignment metadata changed')
    timing=json.loads(timing_blob);pts=timing.get('frame_pts',{}).get('source',timing.get('source_pts'))
    if pts is None or len(pts)!=w['frame_count']: raise ValueError('Explicit displayed source PTS required')
    floor=float(manifest.get('ratio_floor_8bit',.25))
    with np.load(selection_dir/'source-mask.npz') as archive: proof={k:archive[k] for k in archive.files}
    if proof['mask'].shape[0]!=w['frame_count']: raise ValueError('Wrong mask frame count')
    output.mkdir(parents=True,exist_ok=False)
    previous=None;top_changes=[];weighted_history=[]
    with (output/'per-frame.jsonl').open('x') as stream:
        for frame in w['sample_frames']:
            layers={n:window_blocks(r.planes(frame),w['active_rect']) for n,r in raw.items()}
            layers['added']=[a-b for a,b in zip(layers['played'],layers['base'])]
            stats={n:[moments(p) for p in planes] for n,planes in layers.items()}
            actual=[added_stats(p) for p in layers['added']]
            band=proof['band'][frame];mask_bits=proof['mask'][frame]
            occupancy=proof['occupancy'][frame].astype(np.float64);occupancy/=occupancy.sum()
            rows=[];changes=[];stationary=[]
            temporal=temporal_stats(layers['source'],previous['source'],layers['added'],previous['added']) if previous is not None else None
            for mask_name,bit in (('core',1),('expanded',2)):
                for plane_index,plane in enumerate(axes.PLANES):
                    for b in range(8):
                        chosen=((mask_bits&bit)!=0)&(band==b);count=int(chosen.sum())
                        if not count: continue
                        values={n:combine(p[plane_index],chosen,floor) for n,p in stats.items()}
                        row=dict(mask=mask_name,plane=plane,band=[axes.BANDS[b],axes.BANDS[b+1]],
                            occupancy=float(occupancy[b]),patches=count,status='measured' if count>=8 else 'limited_sampling',
                            layers=values,error=axes.comparison(values,floor),exact_added=combine_added(actual[plane_index],chosen),
                            source_below_ratio_reporting_floor=values['source']['amplitude_sigma_8bit']<floor)
                        rows.append(row)
                        if previous is not None:
                            common=chosen&((previous['mask']&bit)!=0)&(previous['band']==b)
                            n=int(common.sum())
                            stationary.append(dict(mask=mask_name,plane=plane,band=b,from_frame=frame-1,to_frame=frame,
                                source_band_occupancy=float(occupancy[b]),
                                **stationary_summary(temporal[plane_index],common,stats['source'][plane_index],actual[plane_index])))
                            if n>=8:
                                def rms(value): return math.sqrt(float(np.mean(value[common])))
                                ds=rms(stats['source'][plane_index]['energy'])-rms(previous['stats']['source'][plane_index]['energy'])
                                dg_absolute=rms(actual[plane_index]['energy'])-rms(previous['actual'][plane_index]['energy'])
                                dg=rms(stats['added'][plane_index]['energy'])-rms(previous['stats']['added'][plane_index]['energy'])
                                dp=rms(stats['played'][plane_index]['energy'])-rms(previous['stats']['played'][plane_index]['energy'])
                                changes.append(dict(mask=mask_name,plane=plane,band=b,from_frame=frame-1,to_frame=frame,
                                    same_source_patch_intersection=n,source_change=ds,added_absolute_rms_change=dg_absolute,added_detrended_sigma_change=dg,
                                    added_change_exceeding_source_change=max(0,abs(dg)-abs(ds)),
                                    played_change_minus_source_change=dp-ds,source_added_directions_disagree=bool(ds*dg<0),
                                    source_luma_mean_change=float(np.mean(proof['luma_mean'][frame][common]-previous['mean'][common])),
                                    interpretation='Descriptive matched-patch source-relative event; compare noise-floor controls before calling flicker'))
            weighted=[]
            for mask_name in ('core','expanded'):
                for plane in axes.PLANES:
                    group=[r for r in rows if r['mask']==mask_name and r['plane']==plane];weight=sum(r['occupancy'] for r in group)
                    if not weight: continue
                    low=[r for r in group if r['source_below_ratio_reporting_floor']];low_weight=sum(r['occupancy'] for r in low)
                    item=dict(frame=frame,mask=mask_name,plane=plane,measured_band_occupancy=weight,
                        source_sigma_8bit=math.sqrt(sum(r['occupancy']*r['layers']['source']['amplitude_sigma_8bit']**2 for r in group)/weight),
                        added_absolute_rms_8bit=math.sqrt(sum(r['occupancy']*r['exact_added']['absolute_rms_8bit']**2 for r in group)/weight),
                        added_nonzero_fraction=sum(r['occupancy']*r['exact_added']['nonzero_fraction'] for r in group)/weight,
                        low_source_band_occupancy=low_weight,
                        added_rms_on_low_source_bands_8bit=math.sqrt(sum(r['occupancy']*r['exact_added']['absolute_rms_8bit']**2 for r in low)/low_weight) if low_weight else None,
                        selected_nonzero_pixels=sum(r['exact_added']['nonzero_pixels'] for r in group),
                        selected_pixels=sum(r['exact_added']['sampled_pixels'] for r in group))
                    weighted.append(item);weighted_history.append(item)
            stream.write(json.dumps(dict(frame=frame,source_time_seconds=float(Fraction(pts[frame])),bands=rows,
                occupancy_weighted=weighted,source_relative_temporal_changes=changes,
                source_stationary_temporal_residuals=stationary),allow_nan=False)+'\n')
            top_changes=sorted(top_changes+changes,key=lambda r:r['added_change_exceeding_source_change'],reverse=True)[:30]
            previous=dict(stats=stats,actual=actual,mask=mask_bits,band=band,mean=proof['luma_mean'][frame],
                source=layers['source'],added=layers['added'])
    axes.dump(output/'summary.json',dict(schema='fgs-frame-safety/1',manifest_sha256=digest,
        id=w['id'],title=w['title'],transfer=w['transfer'],frames=w['frame_count'],every_displayed_frame=True,
        source_mask_review=review['review'],source_ratio_reporting_floor_8bit=floor,
        weighted_per_frame=weighted_history,largest_source_relative_changes=top_changes,
        limits='Spatial source residual includes texture and is not a pure grain oracle. Adjacent-source temporal residual is conditional on source-only mean/low-frequency stability, with eligibility coverage reported; it is a temporal-variation proxy, not motion-compensated grain truth. Source-clean status is uncertain on natural content; exact played-base nonzero/RMS is independent of that uncertainty and has no floor. Flat fills are valid safety evidence; bars are not. Occupancy weighting is conditional on selected flat patches, not all picture pixels. Temporal changes use the same source-coordinate intersection and compare source trends; no universal flicker threshold or library prevalence claim.'))


if __name__=='__main__':
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('mode',choices=('select','score'))
    parser.add_argument('--manifest',required=True)
    parser.add_argument('--selection',help='Reviewed source selection directory for score')
    parser.add_argument('--output',required=True)
    args=parser.parse_args()
    if args.mode=='select': select(args.manifest,args.output)
    else: score(args.manifest,args.selection,args.output)
