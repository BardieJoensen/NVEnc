"""Detect actual grain additions on exactly constant native source patches.

No noise floor, minimum sample count or band averaging can hide a positive.
Every complete active-picture32x32Y/16x16chroma grid block is checked, including
blocks outside the two original low-structure masks. Original encodes are reused.
"""
import argparse,hashlib,json,math
from pathlib import Path
import numpy as np
import frame_safety as s
import grain_axes as axes
import prepare_instrumentation_windows as native

def quantities(source,played,base,plane='Y'):
    constant=np.ptp(source,axis=(-2,-1))==0
    direct=played-base
    clipped=played-np.clip(base,16,235 if plane=='Y' else 240)
    direct_energy=np.mean(direct.astype('float64')**2,axis=(-2,-1))
    clipped_energy=np.mean(clipped.astype('float64')**2,axis=(-2,-1))
    use_clip=clipped_energy<direct_energy
    # Compare entire patches against both possible no-noise outputs. Choosing
    # individual pixels independently would hide a real fluctuating field.
    added=np.where(use_clip[:,None,None],clipped,direct)
    return constant,added,dict(nonzero=np.count_nonzero(added,axis=(-2,-1)),
        direct_nonzero=np.count_nonzero(direct,axis=(-2,-1)),direct_energy=direct_energy,
        null_is_legal_clip=use_clip,
        energy=np.mean(added.astype('float64')**2,axis=(-2,-1)),
        maximum=np.max(np.abs(added),axis=(-2,-1)))

def controls():
    a=np.arange(4*16*16,dtype='float32').reshape(4,16,16)%17;a[0]=80
    b=a.copy();p=b.copy();p[0,3,4]+=.125
    c,g,v=quantities(a,p,b);assert c.tolist()==[True,False,False,False]
    assert v['nonzero'][0]==1 and v['maximum'][0]==.125 and v['energy'][0]>0
    c,g,v=quantities(a,b,b);assert np.all(v['nonzero']==0)
    clean=np.full((1,16,16),16.,dtype='float32');base=clean-.25
    c,g,v=quantities(clean,clean,base);assert v['nonzero'][0]==0 and v['direct_nonzero'][0]==256
    grain=clean.copy();grain[0,3,4]+=.25
    c,g,v=quantities(clean,grain,base);assert v['nonzero'][0]==1 and v['maximum'][0]==.25
    return {'source_self_zero':True,'single_tiny_addition_on_one_clean_patch_in_textured_band_detected':True,'changed_pixels':1,'change_8bit':.125,'legal_clip_only_rejected_as_grain':True,'grain_beyond_legal_clipping_detected':True}

def run(folder,output):
    manifest,digest,w=s.load(folder/'manifest.reviewed.json');assert not output.exists()
    receipt=json.loads((folder/'execution-receipt.json').read_text());assert receipt['complete']
    provenance={}
    for layer in ('source','played','base'):
        pin=receipt['owned_raw_files'][layer];path=Path(w[layer]['path'])
        # Regenerated captures must be byte-identical to the completed original
        # capture; unchanged originals use the already recorded identity/hash.
        if native.identity(path)!=pin['stat']:
            actual=native.hashes(path);assert actual['sha256']==pin['sha256']
            provenance[layer]={'regenerated_byte_identical':True,**actual}
        else:provenance[layer]={'original_identity_unchanged':True,**pin}
    selection=json.loads((folder/'selection/selection.json').read_text());assert selection['manifest_sha256']==digest and selection['review']['complete']
    mask_path=folder/'selection/source-mask.npz';assert hashlib.sha256(mask_path.read_bytes()).hexdigest()==selection['proof_sha256']
    proof=np.load(mask_path);raw={k:axes.Raw(w[k],w['width'],w['height'],w['frame_count']) for k in ('source','played','base')}
    pts=json.loads(Path(w['alignment']['metadata']).read_text())['frame_pts']['source']
    output.mkdir();counts={};examples={};example_arrays={};columns=w['active_rect'][2]//32
    with (output/'per-frame.jsonl').open('x') as stream:
        for frame in range(w['frame_count']):
            layers={k:s.window_blocks(v.planes(frame),w['active_rect']) for k,v in raw.items()};rows=[]
            for p,plane in enumerate(axes.PLANES):
                const,added,stats=quantities(layers['source'][p],layers['played'][p],layers['base'][p],plane)
                positive=const&(stats['nonzero']>0)
                for name,eligible in [('all_active_grid',np.ones_like(const)),('core',(proof['mask'][frame]&1)!=0),('expanded',(proof['mask'][frame]&2)!=0)]:
                    chosen=const&eligible;hit=positive&eligible;key=name+':'+plane
                    total=counts.setdefault(key,dict(frames=0,frames_with_constant_patches=0,frames_with_added_grain_on_constant_source=0,constant_patch_frames=0,positive_patch_frames=0,constant_pixels=0,changed_pixels=0,max_added_rms_8bit=0.0,clipping_only_patch_frames=0))
                    total['clipping_only_patch_frames']+=int(np.count_nonzero(chosen&(stats['direct_nonzero']>0)&(stats['nonzero']==0)))
                    total['frames']+=1;total['frames_with_constant_patches']+=bool(chosen.any());total['frames_with_added_grain_on_constant_source']+=bool(hit.any());total['constant_patch_frames']+=int(chosen.sum());total['positive_patch_frames']+=int(hit.sum());total['constant_pixels']+=int(chosen.sum())*added.shape[-1]**2;total['changed_pixels']+=int(stats['nonzero'][chosen].sum())
                    if hit.any():total['max_added_rms_8bit']=max(total['max_added_rms_8bit'],float(np.sqrt(stats['energy'][hit].max())))
                    for band in range(8):
                        cell=chosen&(proof['band'][frame]==band);positive_cell=hit&(proof['band'][frame]==band)
                        if cell.any():rows.append(dict(mask=name,plane=plane,band=[band*32,(band+1)*32],constant_patches=int(cell.sum()),positive_patches=int(positive_cell.sum()),constant_pixels=int(cell.sum())*added.shape[-1]**2,changed_pixels=int(stats['nonzero'][cell].sum()),added_rms_8bit=float(np.sqrt(stats['energy'][cell].mean())),max_patch_added_rms_8bit=float(np.sqrt(stats['energy'][cell].max()))))
                if positive.any():
                    index=int(np.argmax(np.where(positive,stats['energy'],-1)));strength=float(np.sqrt(stats['energy'][index]))
                    if plane not in examples or strength>examples[plane]['added_rms_8bit']:
                        y,x=divmod(index,columns);examples[plane]=dict(frame=frame,source_pts=pts[frame],block=index,x=w['active_rect'][0]+x*32,y=w['active_rect'][1]+y*32,source_constant_code_8bit=float(layers['source'][p][index,0,0]),source_luma_band=int(proof['band'][frame,index]),added_rms_8bit=strength,changed_pixels=int(stats['nonzero'][index]),maximum_added_8bit=float(stats['maximum'][index]),mask_bits=int(proof['mask'][frame,index]))
                        for layer in layers:example_arrays[plane+'_'+layer]=layers[layer][p][index].copy()
            stream.write(json.dumps({'frame':frame,'source_pts':pts[frame],'bands':rows})+'\n')
    np.savez_compressed(output/'native-max-examples.npz',**example_arrays)
    report={'schema':'fgs-constant-patch-safety/2','id':w['id'],'complete':True,'frames':w['frame_count'],'controls':controls(),'counts':counts,'max_examples':examples,'raw_provenance':provenance,'manifest_sha256':digest,'mask_sha256':selection['proof_sha256'],'meaning':'Exactly constant source32Y/16chroma patches have zero resolved spatial grain; report any difference beyond the closer whole-patch no-grain null: unchanged base or base clipped to legal Y16..235/chroma16..240. This conservative test excludes clipping-only correction, with no noise floor or8-patch minimum. All active grid blocks exclude reviewed bars but omit incomplete right/bottom blocks. Finite patch/frame incidence is not library prevalence; no assumption that a whole title is clean.'}
    (output/'summary.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps({'id':w['id'],'counts':counts,'max_examples':examples}))

if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('--folder',type=Path);p.add_argument('--output',type=Path);p.add_argument('--controls',action='store_true');a=p.parse_args()
    if a.controls:print(json.dumps(controls()))
    else:run(a.folder,a.output)
