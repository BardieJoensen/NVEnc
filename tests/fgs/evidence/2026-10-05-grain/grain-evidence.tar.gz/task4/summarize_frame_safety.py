#!/usr/bin/env python3
"""Summarize explicitly named every-frame receipts; no media discovery or encoding."""
import argparse
from collections import defaultdict
import hashlib
import json
import math
from pathlib import Path


def summarize(folder):
    metadata=json.loads((folder/'summary.json').read_text())
    groups={}; frames=0
    for line in (folder/'per-frame.jsonl').open():
        f=json.loads(line);frames+=1; current=defaultdict(list)
        for row in f['bands']:
            key=(row['mask'],row['plane'],tuple(row['band']))
            if key not in groups:
                groups[key]=dict(frames_present=0,frames_measured=0,limited_frames=0,weight=0.,
                    excess_frames_any=0,excess_frames_ge_quarter_code=0,zero_source_with_added_frames=0,
                    low_source_with_added_frames=0,excess_band_occupancy_sum=0.,energy=defaultdict(float),
                    hf_energy=defaultdict(float),lag_numerator=defaultdict(float),lag_weight=defaultdict(float),
                    added_energy=0.,max_excess=None,events=[],any_excess_frame_indices=[],limited_excess_events=[],stationary_frames=0,exactly_unchanged_source_frames=0,
                    unchanged_source_with_added_temporal_frames=0,max_unchanged_added_temporal=0.)
            g=groups[key];g['frames_present']+=1
            if row['patches']<8:
                g['limited_frames']+=1
                src=row['layers']['source']['amplitude_sigma_8bit'];added=row['exact_added']['absolute_rms_8bit'];grain_sigma=row['layers']['added']['amplitude_sigma_8bit']
                if grain_sigma-src>1e-12 or (src<=1e-12 and row['exact_added']['any_nonzero']):
                    g['limited_excess_events'].append(dict(frame=f['frame'],source_time_seconds=f['source_time_seconds'],
                        source_sigma_8bit=src,added_rms_8bit=added,added_detrended_sigma_8bit=grain_sigma,source_band_occupancy=row['occupancy'],patches=row['patches']))
                continue
            g['frames_measured']+=1;w=row['occupancy'];g['weight']+=w
            src=row['layers']['source']['amplitude_sigma_8bit'];added=row['exact_added']['absolute_rms_8bit'];grain_sigma=row['layers']['added']['amplitude_sigma_8bit'];excess=grain_sigma-src
            for layer,values in row['layers'].items():
                energy=values['amplitude_sigma_8bit']**2;g['energy'][layer]+=w*energy;g['hf_energy'][layer]+=w*values['hf_sigma_8bit']**2
                for lag,value in values['acf'].items():
                    if value is not None:
                        k=layer+':'+lag;g['lag_numerator'][k]+=w*energy*value;g['lag_weight'][k]+=w*energy
            g['added_energy']+=w*added*added
            g['excess_frames_any']+=excess>1e-12
            if excess>1e-12:g['any_excess_frame_indices'].append(f['frame'])
            g['excess_frames_ge_quarter_code']+=excess>=.25
            g['zero_source_with_added_frames']+=(src<=1e-12 and row['exact_added']['any_nonzero'])
            g['low_source_with_added_frames']+=(src<.25 and row['exact_added']['any_nonzero'])
            if excess>=.25:g['excess_band_occupancy_sum']+=w
            event=dict(frame=f['frame'],source_time_seconds=f['source_time_seconds'],source_sigma_8bit=src,
                added_rms_8bit=added,added_detrended_sigma_8bit=grain_sigma,added_minus_source_8bit=excess,source_band_occupancy=w,patches=row['patches'])
            if g['max_excess'] is None or excess>g['max_excess']['added_minus_source_8bit']:g['max_excess']=event
            if excess>=.25 or (src<=1e-12 and row['exact_added']['any_nonzero']):g['events'].append(event)
            current[(row['mask'],row['plane'])].append((row,event))
        for row in f['source_stationary_temporal_residuals']:
            key=(row['mask'],row['plane'],(row['band']*32,(row['band']+1)*32))
            if key not in groups or row['stationary_patches']<8:continue
            g=groups[key];g['stationary_frames']+=1
            if row['source_changed_pixels']==0:
                g['exactly_unchanged_source_frames']+=1
                value=row['added_temporal_residual_sigma_div_sqrt2_8bit']
                g['unchanged_source_with_added_temporal_frames']+=value>1e-12
                g['max_unchanged_added_temporal']=max(g['max_unchanged_added_temporal'],value)
    assert frames==metadata['frames']
    output=[]
    for (mask,plane,band),g in sorted(groups.items()):
        w=g.pop('weight');energy=g.pop('energy');hf=g.pop('hf_energy');ln=g.pop('lag_numerator');lw=g.pop('lag_weight');added=g.pop('added_energy')
        g.update(mask=mask,plane=plane,band=list(band),mean_measured_band_occupancy=w/frames,
            occupancy_weighted_axes={layer:dict(amplitude_sigma_8bit=math.sqrt(e/w),hf_sigma_8bit=math.sqrt(hf[layer]/w),
                acf={lag:ln[layer+':'+lag]/lw[layer+':'+lag] if lw[layer+':'+lag] else None for lag in ('h1','h2','v1','v2')}) for layer,e in energy.items()} if w else {},
            added_absolute_rms_8bit=math.sqrt(added/w) if w else None)
        output.append(g)
    # Union events across brightness bands gives per-plane frame incidence.
    incidence=[]
    for mask in ('core','expanded'):
        for plane in ('Y','Cb','Cr'):
            rows=[g for g in output if g['mask']==mask and g['plane']==plane]
            events={e['frame'] for g in rows for e in g['events']}
            any_excess={i for g in rows for i in g['any_excess_frame_indices']}
            limited={e['frame'] for g in rows for e in g['limited_excess_events']}
            material={e['frame'] for g in rows for e in g['events'] if e['added_minus_source_8bit']>=.25}
            zero={e['frame'] for g in rows for e in g['events'] if e['source_sigma_8bit']<=1e-12}
            incidence.append(dict(mask=mask,plane=plane,total_evaluation_frames=frames,
                frames_with_any_measured_excess=len(any_excess),frames_with_limited_sample_excess=len(limited),
                frames_with_excess_ge_quarter_code=len(material),frames_with_zero_source_and_any_added=len(zero),
                event_union_frames=len(events),fraction_with_excess_ge_quarter_code=len(material)/frames,
                mean_occupied_luma_band_fraction_with_excess_ge_quarter_code=sum(g['excess_band_occupancy_sum'] for g in rows)/frames,
                mean_measured_band_occupancy=sum(g['mean_measured_band_occupancy'] for g in rows)))
    return dict(id=metadata['id'],title=metadata['title'],transfer=metadata['transfer'],frames=frames,
        metadata_path=str(folder/'summary.json'),metadata_sha256=hashlib.sha256((folder/'summary.json').read_bytes()).hexdigest(),
        per_frame_sha256=hashlib.file_digest((folder/'per-frame.jsonl').open('rb'),'sha256').hexdigest(),
        per_plane_incidence=incidence,bands=output,largest_source_relative_changes=metadata['largest_source_relative_changes'],
        limits=metadata['limits'],thresholds=dict(quarter_code_excess_8bit=.25,zero_tolerance_8bit=1e-12,minimum_patches=8),
        interpretation='Excess compares affine-detrended sigma on both source and added grain; exact raw RMS/nonzeros remain separate. All nonzero addition remains in original receipts; quarter-code excess is a descriptive size bin, not a universal visibility threshold or a permission to add grain. Incidence applies only to these fixed windows and source-selected patches.')


def main():
    ap=argparse.ArgumentParser(description=__doc__);ap.add_argument('--metrics',required=True,type=Path,action='append');ap.add_argument('--output',required=True,type=Path);args=ap.parse_args()
    result=dict(schema='fgs-frame-safety-census/1',windows=[summarize(p) for p in args.metrics])
    with args.output.open('x') as f:json.dump(result,f,indent=2,allow_nan=False);f.write('\n')

if __name__=='__main__':main()
