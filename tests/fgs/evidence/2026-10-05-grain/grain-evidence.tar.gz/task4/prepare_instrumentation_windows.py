#!/usr/bin/env python3
"""Prepare bounded native windows from completed deployed instrumentation arms.

Default mode writes commands only and opens NO source/IVF media. --execute is
for the parent after tasks 1-3: source NVEnc raw decode uses the recorded input
options/seek, without FGS; existing production IVF is decoded with grain on/off.
There is no encode, source discovery, crop approval, or metric optimization.
"""
import argparse
from fractions import Fraction
import hashlib
import json
import os
from pathlib import Path
import re
import resource
import shutil
import signal
import struct
import subprocess
import threading
import time

ROOT = Path('/tmp/downloads/codex-work/fgs-submission-20261005')
PRODUCTION_SHA = 'c6cbd5280440c62b51c3b43ced4570dad40295748d42f562a867ac6a525be72b'
BUDGET = 12 << 30
DEFAULT_WINDOWS = [('losttapes', 96, 32), ('gentlemen', 96, 32), ('taxi_hdr', 0, 24)]


def write(path, value):
    with Path(path).open('x') as stream:
        json.dump(value, stream, indent=2, allow_nan=False)
        stream.write('\n')


def identity(path):
    s = Path(path).stat()
    return [s.st_dev, s.st_ino, s.st_size, s.st_mtime_ns, s.st_ctime_ns]


def hashes(path):
    before = identity(path)
    sha, md5 = hashlib.sha256(), hashlib.md5()
    with Path(path).open('rb') as stream:
        for block in iter(lambda: stream.read(4 << 20), b''):
            sha.update(block); md5.update(block)
    if identity(path) != before:
        raise ValueError('File changed during read: ' + str(path))
    return dict(sha256=sha.hexdigest(), md5=md5.hexdigest(), stat=before)


def ffmpeg_command(ffmpeg, ivf, start, count, grain, output):
    return [ffmpeg, '-nostdin', '-v', 'info', '-xerror', '-n', '-copyts',
            '-c:v', 'libdav1d', '-threads', '2', '-filmgrain', str(grain),
            '-i', str(ivf), '-map', '0:v:0', '-an', '-sn', '-dn',
            '-vf', f'trim=start_frame={start}:end_frame={start + count},showinfo',
            '-frames:v', str(count), '-fps_mode', 'passthrough',
            '-pix_fmt', 'yuv420p10le', '-threads', '1', '-f', 'rawvideo', str(output)]


def prepare(report_path, output, requested):
    report = json.loads(report_path.read_text())
    manifest = report['manifest']
    arm = next(a for a in manifest['arms'] if a['name'] == 'deployed')
    if arm['sha256'] != PRODUCTION_SHA or arm.get('trace') or arm.get('prefix'):
        raise ValueError('Only the original deployed production binary is accepted')
    inputs = {i['name']: i for i in manifest['inputs']}
    ffmpeg, ffprobe = shutil.which('ffmpeg'), shutil.which('ffprobe')
    if not ffmpeg or not ffprobe:
        raise ValueError('ffmpeg and ffprobe required')
    windows = []
    for name, start, count in requested:
        if not 0 <= start or not 24 <= count <= 32:
            raise ValueError('Windows are explicitly bounded to 24..32 frames')
        item = inputs[name]
        rows = [r for r in report['runs'] if r['input'] == name and r['arm'] == 'deployed'
                and r['stage'] == 'av1' and r.get('complete') and r.get('returncode') == 0]
        if not rows:
            raise ValueError('No completed deployed encode yet: ' + name)
        row = min(rows, key=lambda r: r['repeat'])
        if row['binary_sha256'] != PRODUCTION_SHA or row['source_sha256'] != item['sha256']:
            raise ValueError('Production/source binding mismatch')
        if start + count > row['packets'] or item['output_depth'] != 10:
            raise ValueError('Window outside complete 10-bit production encode')
        if not item['original_source'] or '--timestamp-passthrough' not in item['input_args']:
            raise ValueError('Require explicit original and passthrough timestamp inputs')
        folder = output / name
        ivf = Path(row['directory']) / 'video.ivf'
        source = [arm['binary']] + item['input_args'] + ['--allow-other-negative-pts']
        if item.get('seek') is not None:
            source += ['--seek', str(item['seek'])]
        source += ['-i', item['path'], '--frames', str(start + count), '--codec', 'raw',
                   '--output-depth', '10'] + item['color_args']
        source += ['--output-format', 'y4m', '--y4m-timestamp', '-o', '-']
        window = dict(name=name, start=start, count=count, item=item, encoded=row,
            folder=str(folder), ivf=str(ivf), source_raw=str(folder / 'source.yuv'),
            played_raw=str(folder / 'played.yuv'), base_raw=str(folder / 'base.yuv'),
            source_command=source,
            source_probe_command=[ffprobe, '-v', 'error', '-select_streams', 'v:0',
                '-show_entries', 'stream=width,height,pix_fmt,color_range,color_space,color_transfer,color_primaries,time_base,r_frame_rate',
                '-of', 'json', item['path']],
            played_command=ffmpeg_command(ffmpeg, ivf, start, count, 1, folder / 'played.yuv'),
            base_command=ffmpeg_command(ffmpeg, ivf, start, count, 0, folder / 'base.yuv'))
        windows.append(window)
    expected = sum(w['encoded']['width'] * w['encoded']['height'] * 3 * w['count'] * 3 for w in windows)
    if expected > BUDGET:
        raise ValueError('Raw windows exceed the 12 GiB cap')
    return dict(schema='fgs-instrumentation-window-plan/1', report=str(report_path),
        report_sha256=hashlib.sha256(report_path.read_bytes()).hexdigest(),
        production_binary_sha256=PRODUCTION_SHA, output=str(output),
        expected_raw_bytes=expected, budget_bytes=BUDGET, windows=windows,
        source_pins={w['item']['path']: report['pins'][w['item']['path']] for w in windows},
        notes=['This plan opens metadata only; --execute opens media and may use NVDEC.',
               'Source prefix is streamed and discarded, retaining only the selected raw window.',
               'No output is scored until active-picture/source-patch inspection and alignment checks.',
               'These are short encode histories, not full-history Play Dirty witnesses.'])


def run(command, log, timeout, max_file_size):
    env = os.environ.copy(); env.pop('NVENC_TRACE_SUBMISSION', None)
    def limit():
        resource.setrlimit(resource.RLIMIT_FSIZE, (max_file_size, max_file_size))
    with Path(log).open('xb') as stream:
        process = subprocess.Popen(command, stdout=stream, stderr=subprocess.STDOUT,
            env=env, stdin=subprocess.DEVNULL, start_new_session=True, preexec_fn=limit)
        try:
            rc = process.wait(timeout=timeout)
        except BaseException:
            os.killpg(process.pid, signal.SIGKILL); process.wait(); raise
    if rc:
        raise RuntimeError('Command failed; see ' + str(log))


def exact_read(stream, count):
    chunks, remaining = [], count
    while remaining:
        block = stream.read(remaining)
        if not block:
            raise ValueError('Truncated source Y4M frame')
        chunks.append(block); remaining -= len(block)
    return b''.join(chunks)


def decode_source(window, timeout):
    folder = Path(window['folder']); row = window['encoded']
    frame_bytes = row['width'] * row['height'] * 3
    total = window['start'] + window['count']
    env = os.environ.copy(); env.pop('NVENC_TRACE_SUBMISSION', None)
    started = time.monotonic(); rows = []
    with (folder / 'source-decode.log').open('xb') as log, Path(window['source_raw']).open('xb') as target:
        process = subprocess.Popen(window['source_command'], stdout=subprocess.PIPE, stderr=log,
            stdin=subprocess.DEVNULL, env=env, start_new_session=True)
        timer = threading.Timer(timeout, lambda: os.killpg(process.pid, signal.SIGKILL) if process.poll() is None else None)
        timer.start()
        try:
            header = process.stdout.readline(2048).decode('ascii')
            fields = header.split()
            if (fields[0] != 'YUV4MPEG2' or f'W{row["width"]}' not in fields
                or f'H{row["height"]}' not in fields or 'C420p10' not in fields
                or not any(f.startswith('XTIMEBASE=') for f in fields)):
                raise ValueError('Expected exact geometry, native planar 10-bit, and timestamped Y4M')
            for index in range(total):
                marker = process.stdout.readline(2048).decode('ascii')
                match = re.fullmatch(r'FRAME Xts=(-?\d+\.\d+)(?: Xdur=(\d+\.\d+))?\n', marker)
                if not match:
                    raise ValueError('Source display-frame timestamp missing: ' + repr(marker))
                pixels = exact_read(process.stdout, frame_bytes)
                rows.append(dict(index=index, pts=match[1], duration=match[2]))
                if index >= window['start']:
                    target.write(pixels)
            if process.stdout.read(1) or process.wait(timeout=30):
                raise ValueError('Source decoder did not finish at the requested frame count')
        except BaseException:
            if process.poll() is None: os.killpg(process.pid, signal.SIGKILL)
            process.wait(); raise
        finally:
            timer.cancel()
    receipt = dict(argv=window['source_command'], y4m_header=header.strip(), frames=rows,
        selected_frames=rows[window['start']:], elapsed_seconds=time.monotonic() - started,
        source_values='Native code values; 8-bit inputs are shifted exactly into 10-bit containers, no FGS or range conversion')
    write(folder / 'source-display-pts.json', receipt)
    return [Fraction(r['pts']) for r in receipt['selected_frames']]


def decode_pts(log, count):
    text = Path(log).read_text(errors='replace')
    bases = set(re.findall(r'config in time_base:\s*(\d+/\d+)', text))
    if len(bases) != 1:
        raise ValueError('Missing or changing showinfo timebase')
    base = Fraction(bases.pop())
    matches = re.findall(r'\bn:\s*(\d+)\s+pts:\s*(-?\d+)\s+pts_time:', text)
    # ffmpeg may evaluate one extra filter frame when the mux output limit fires.
    # The trim filter bounds the admitted frames, so demand exactly count here.
    if len(matches) != count or [int(n) for n, _ in matches] != list(range(count)):
        raise ValueError('Wrong displayed frame count/order in showinfo')
    return [int(pts) * base for _, pts in matches]


def execute(plan, timeout):
    output = Path(plan['output'])
    if not output.resolve().is_relative_to(ROOT / 'task4'):
        raise ValueError('Output must stay under task4 scratch')
    if shutil.disk_usage(ROOT).free < plan['expected_raw_bytes'] + (2 << 30):
        raise ValueError('Insufficient free space for bounded raw output plus headroom')
    output.mkdir(parents=True, exist_ok=False)
    write(output / 'plan.json', plan)
    result = dict(schema='fgs-instrumentation-window-execution/1', complete=False, windows=[])
    try:
        binary = plan['windows'][0]['source_command'][0]
        if hashes(binary)['sha256'] != PRODUCTION_SHA:
            raise ValueError('Wrong production binary')
        decoder = hashes(plan['windows'][0]['played_command'][0])
        metric_windows = []
        for w in plan['windows']:
            source = w['item']['path']; pin = plan['source_pins'][source]
            if pin['sha256'] != w['item']['sha256'] or identity(source) != pin['stat']:
                raise ValueError('Original source metadata differs from pinned encode')
            folder = Path(w['folder']); folder.mkdir()
            encoded = hashes(w['ivf'])
            if encoded['md5'] != w['encoded']['file_md5']:
                raise ValueError('Existing production IVF differs from completed encode receipt')
            # The identity runner already parsed every IVF packet, retaining actual PTS.
            row = w['encoded']; rate, scale = row['rate'], row['scale']
            packet_pts = [Fraction(v * scale, rate) for v in row['timestamps'][w['start']:w['start'] + w['count']]]
            write(folder / 'ivf-pts.json', dict(source='completed byte-matched identity IVF packet parse',
                original_report=plan['report'], time_base=f'{scale}/{rate}', pts=[str(v) for v in packet_pts]))
            run(w['source_probe_command'], folder / 'source-probe.json', timeout, 16 << 20)
            probe = json.loads((folder / 'source-probe.json').read_text())['streams'][0]
            if (probe['width'] != row['width'] or probe['height'] != row['height']
                or probe['pix_fmt'] not in ('yuv420p', 'yuv420p10le')):
                raise ValueError('Expected unchanged native 8/10-bit YUV420 source geometry')
            source_pts = decode_source(w, timeout)
            expected = row['width'] * row['height'] * 3 * w['count']
            for name in ('played', 'base'):
                run(w[name + '_command'], folder / (name + '-decode.log'), timeout, expected + (1 << 20))
                if Path(w[name + '_raw']).stat().st_size != expected:
                    raise ValueError('Wrong raw decoded byte count')
            on = decode_pts(folder / 'played-decode.log', w['count'])
            off = decode_pts(folder / 'base-decode.log', w['count'])
            if on != off or on != packet_pts:
                raise ValueError('Decoded displayed PTS do not match the recorded IVF packet mapping')
            offset = source_pts[0] - on[0]
            frame_period = Fraction(scale, rate)
            if abs(offset) > frame_period / 2 + Fraction(1, 1000):
                raise ValueError('Source/IVF time-origin discrepancy exceeds half a frame; inspect source mapping')
            if max(abs(s - p - offset) for s, p in zip(source_pts, on)) > Fraction(11, 10000):
                raise ValueError('Source/IVF mapping is not a constant sub-frame origin offset')
            metadata = dict(schema='fgs-native-window-extraction/1', production_binary_sha256=PRODUCTION_SHA,
                source_original_sha256=w['item']['sha256'], played_bitstream_sha256=encoded['sha256'],
                base_bitstream_sha256=encoded['sha256'], decoder_binary_sha256=decoder['sha256'],
                source_decode_argv=w['source_command'], played_decode_argv=w['played_command'], base_decode_argv=w['base_command'],
                pts_extraction_receipt=str(folder / 'source-display-pts.json'),
                source_minus_output_pts=str(offset), pts_tolerance_seconds='11/10000',
                frame_pts={k:[str(v) for v in values] for k,values in [('source',source_pts),('played',on),('base',off)]},
                source_to_output_offset_explanation='Measured source Xts versus IVF display grid; strictly less than half a frame, remaining jitter <=1.1 ms; independent pixel-offset check still required',
                source_probe=probe, ivf_receipt=encoded)
            write(folder / 'extraction-metadata.json', metadata)
            if identity(source) != pin['stat'] or identity(w['ivf']) != encoded['stat']:
                raise ValueError('Pinned source/IVF changed during extraction')
            transfer = probe.get('color_transfer', 'unknown')
            if w['name'] == 'gentlemen' and transfer == 'unknown':
                transfer = 'SDR-unspecified'
            window = dict(id=w['name'] + '-initial', title=w['name'], content_class='live-action',
                transfer=transfer, range=probe.get('color_range','unknown'), qvbr=w['item']['qvbr'],
                source_sha256=w['item']['sha256'], width=row['width'], height=row['height'],
                frame_count=w['count'], sample_frames=list(range(w['count'])),
                active_rect=[0,0,row['width'],row['height']], active_rect_reviewed=False, active_rect_evidence=None,
                alignment=dict(metadata=str(folder / 'extraction-metadata.json'), receipt=str(output / 'alignment.json')),
                source=dict(path=w['source_raw'],bits=10), played=dict(path=w['played_raw'],bits=10), base=dict(path=w['base_raw'],bits=10))
            metric_windows.append(window)
            result['windows'].append(dict(id=window['id'], complete=True, raw_bytes=expected * 3,
                original_source_unchanged=True, production_ivf_sha256=encoded['sha256'], source_output_origin_offset=str(offset)))
        write(output / 'manifest.pending-review.json', dict(schema='fgs-grain-axes/1',
            production_receipt=str(output / 'plan.json'), production_binary_sha256=PRODUCTION_SHA,
            ratio_floor_8bit=.25, windows=metric_windows))
        result['complete'] = True
    finally:
        write(output / 'execution-receipt.json', result)


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--report', type=Path, default=ROOT / 'instrumentation/report.json')
    parser.add_argument('--output', type=Path, default=ROOT / 'task4/instrumentation-windows')
    parser.add_argument('--plan-file', type=Path, default=ROOT / 'task4/instrumentation-window-plan.json')
    parser.add_argument('--execute', action='store_true', help='Opens original/source media; parent coordinates GPU availability first')
    parser.add_argument('--timeout', type=int, default=900)
    args = parser.parse_args()
    plan = prepare(args.report, args.output, DEFAULT_WINDOWS)
    if args.execute:
        execute(plan, args.timeout)
    else:
        write(args.plan_file, plan)
        print(json.dumps({'plan':str(args.plan_file),'expected_raw_bytes':plan['expected_raw_bytes'],'media_opened':False}))
