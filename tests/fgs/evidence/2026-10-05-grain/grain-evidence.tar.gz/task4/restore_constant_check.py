"""Restore released owned raw from existing IVF/source commands, hash-check, scan.

No new AV1 encode, original-media discovery, overwrite, or metric gate change.
Source decode and grain-on/off captures must reproduce the original raw SHA256s.
"""
from pathlib import Path
import argparse,fcntl,hashlib,json,subprocess,sys,time
import numpy as np
import grain_axes as axes
import heldout_measurement as held
import prepare_instrumentation_windows as native

p=argparse.ArgumentParser();p.add_argument('--folder',type=Path,required=True);a=p.parse_args()
folder=a.folder.resolve();root=Path(__file__).resolve().parent
assert folder.is_relative_to(root)
with (root/'.heldout-measurement.lock').open('a') as lock:
    fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB)
    entry=json.loads((folder/'commands.json').read_text());old=json.loads((folder/'execution-receipt.json').read_text())
    assert old['complete'] and json.loads((folder/'raw-release.json').read_text())['released']
    assert not (folder/'constant-patches-v2').exists()
    for layer in ('source','played','base'):
        path=Path(entry[layer+'_raw']);assert path.parent==folder and not path.exists()
    assert held.raw_usage(root)+entry['raw_bytes_total']<=held.RAW_BUDGET
    held.validate_source(entry)
    assert native.hashes(entry['source_command'][0])['sha256']==native.PRODUCTION_SHA
    assert native.hashes(entry['ivf'])['sha256']==old['ivf_hash']['sha256']
    metadata=json.loads((folder/'extraction-metadata.json').read_text())
    assert native.hashes(entry['played_command'][0])['sha256']==metadata['decoder_binary_sha256']
    scratch=folder/'constant-recapture';scratch.mkdir(exist_ok=False)
    status={'complete':False,'released':False,'new_av1_encode':False,'started_utc':time.strftime('%Y-%m-%dT%H:%M:%SZ',time.gmtime())}
    try:
        window=dict(entry,folder=str(scratch),encoded=old['ivf'])
        pts=native.decode_source(window,900)
        assert list(map(str,pts))==metadata['frame_pts']['source']
        for layer in ('played','base'):
            native.run(entry[layer+'_command'],scratch/(layer+'-decode.log'),900,entry['raw_bytes_each']+(1<<20))
            assert list(map(str,native.decode_pts(scratch/(layer+'-decode.log'),entry['count'])))==metadata['frame_pts'][layer]
        held.validate_source(entry)
        with (scratch/'checker.log').open('x') as log:
            subprocess.run([sys.executable,str(root/'constant_patch_safety.py'),'--folder',str(folder),'--output',str(folder/'constant-patches-v2')],check=True,stdout=log)
        result=json.loads((folder/'constant-patches-v2/summary.json').read_text());assert result['complete']
        witness=folder/'constant-event-witness/native-event-frames.npz'
        if witness.exists():
            wr=json.loads((witness.parent/'receipt.json').read_text());w=json.loads((folder/'manifest.reviewed.json').read_text())['windows'][0]
            with np.load(witness) as archive:
                for layer in ('source','base','played'):
                    raw=axes.Raw(w[layer],w['width'],w['height'],w['frame_count'])
                    for index in wr['frames']:
                        for plane,pixels in zip(axes.PLANES,raw.planes(index)):
                            assert np.array_equal(archive[f'{layer}_{index}_{plane}'],np.rint(pixels*4).astype('uint16'))
            status['witness_archive_matches_original_raw']=hashlib.file_digest(witness.open('rb'),'sha256').hexdigest()
        # The checker verifies every restored raw hash against its original receipt.
        status.update(complete=True,restored_raw=result['raw_provenance'])
        native.write(scratch/'verified-before-release.json',status)
        for layer,v in result['raw_provenance'].items():
            path=Path(entry[layer+'_raw']);assert native.identity(path)==v['stat'];path.unlink()
        status['released']=True
    finally:
        held.validate_source(entry);status['finished_utc']=time.strftime('%Y-%m-%dT%H:%M:%SZ',time.gmtime());native.write(scratch/'receipt.json',status)
    print(json.dumps({'id':entry['id'],'byte_identical_raw_restored_and_released':status['complete'] and status['released']}))
