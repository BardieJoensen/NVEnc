"""Timestamp-checked native witness from the completed full-history MKV."""
from pathlib import Path
from fractions import Fraction
import json,shutil,subprocess,sys
import numpy as np
import heldout_measurement as held
import prepare_instrumentation_windows as native

root=Path(__file__).resolve().parent;old=root/'heldout-windows-capture3/insidious-p70'
parent=root/'insidious-full-history-confirmation';receipt=json.loads((parent/'encode-receipt.json').read_text());assert receipt['complete']
folder=parent/'event';folder.mkdir();assert held.raw_usage(root)+1920*1080*3*16*3<held.RAW_BUDGET
video=parent/'video.mkv';assert native.hashes(video)['sha256']==receipt['output']['sha256']
metadata=json.loads((old/'extraction-metadata.json').read_text());source_pts=[Fraction(v) for v in metadata['frame_pts']['source'][134:150]]
data=np.load(old/'constant-event-witness/native-event-frames.npz')
with (folder/'source.yuv').open('xb') as f:
    for i in range(134,150):
        for plane in ('Y','Cb','Cr'):f.write(data[f'source_{i}_{plane}'].astype('<u2').tobytes())
commands={};decoded={}
for layer,grain in [('played',1),('base',0)]:
    command=native.ffmpeg_command(shutil.which('ffmpeg'),video,0,16,grain,folder/(layer+'.yuv'))
    i=command.index('-i');command[i:i]=['-ss',f'{float(source_pts[0])-0.5:.9f}']
    command[command.index('-vf')+1]=f"select='gte(t,{float(source_pts[0])-0.0021:.9f})',trim=end_frame=16,showinfo"
    commands[layer]=command;native.run(command,folder/(layer+'-decode.log'),180,1920*1080*3*16+(1<<20))
    decoded[layer]=native.decode_pts(folder/(layer+'-decode.log'),16)
assert decoded['played']==decoded['base'];pts=decoded['played']
assert max(abs(a-b) for a,b in zip(pts,source_pts))<=Fraction(11,10000)
digest=receipt['output']['sha256'];metadata.update(played_bitstream_sha256=digest,base_bitstream_sha256=digest,played_decode_argv=commands['played'],base_decode_argv=commands['base'],source_minus_output_pts=str(source_pts[0]-pts[0]),frame_pts={'source':list(map(str,source_pts)),'played':list(map(str,pts)),'base':list(map(str,pts))},evaluation_frames=16,source_subset={'archive':str(old/'constant-event-witness/native-event-frames.npz'),'original_evaluation_frames':list(range(134,150))},full_history_encode_receipt=str(parent/'encode-receipt.json'))
native.write(folder/'extraction-metadata.json',metadata)
manifest=json.loads((old/'manifest.reviewed.json').read_text());w=manifest['windows'][0];w.update(id='insidious-full-history-constant-event',frame_count=16,sample_frames=list(range(16)),alignment={'metadata':str(folder/'extraction-metadata.json'),'receipt':str(folder/'alignment.json')})
for layer in ('source','played','base'):w[layer]['path']=str(folder/(layer+'.yuv'))
manifest['production_receipt']=str(parent/'encode-receipt.json');native.write(folder/'manifest.reviewed.json',manifest)
native.write(folder/'execution-receipt.json',{'complete':True,'full_history_frames':receipt['frames'],'event_count':16,'video_sha256':digest,'owned_raw_files':{name:native.hashes(folder/(name+'.yuv'))|{'path':str(folder/(name+'.yuv'))} for name in ('source','played','base')}})
for command in ([sys.executable,str(root/'align_native_windows.py'),'--manifest',str(folder/'manifest.reviewed.json'),'--output',str(folder/'alignment.json')],
                [sys.executable,str(root/'frame_safety.py'),'select','--manifest',str(folder/'manifest.reviewed.json'),'--output',str(folder/'selection')],
                [sys.executable,str(root/'render_source_mask_proof.py'),'--manifest',str(folder/'manifest.reviewed.json'),'--selection',str(folder/'selection'),'--output',str(folder/'source-proof')]):subprocess.run(command,check=True)
print('SOURCE MASK REVIEW REQUIRED: '+str(folder/'source-proof/source-masks.png'))
