#!/usr/bin/env python3
"""Six-level synthetic amplitude diagnostic; generate is CPU-only, run uses GPU.

Not a library qualification gate. No originals, plain controls or encoder edits.
"""
import argparse
from fractions import Fraction
import hashlib
import json
import os
from pathlib import Path
import re
import shutil
import struct

import numpy as np
import grain_axes as axes
import prepare_instrumentation_windows as helper

ROOT = helper.ROOT / 'task4'
DEFAULT = ROOT / 'amplitude-response'
BIN = Path('/tmp/downloads/codex-work/fgs-improvement-20261004/bin/nvencc-deployed')
GAINS = (0, .5, 1, 2, 4, 6)
W, H, FRAMES, FIRST, COUNT = 960, 540, 96, 64, 32
RATE, SCALE, SEED = 24000, 1001, 20261005
SOURCE_CAP = int(1.2 * (1 << 30))
CORE = ['--max-bitrate','50000','--preset','quality','--tune','hq',
        '--lookahead','32','--lookahead-level','3','--aq','--aq-temporal']


def label(gain):
    return 'gain-' + str(gain).replace('.', 'p')


def bases():
    result = []
    for plane in range(3):
        factor = 1 if plane == 0 else 2
        width, height, band, half = W // factor, H // factor, 160 // factor, 16 // factor
        centers = np.asarray([48,80,112,144,176,208] if plane == 0 else
                             [96,104,112,120,128,136] if plane == 1 else
                             [160,152,144,136,128,120], dtype=np.float64)
        row = np.repeat(centers, band)
        for index in range(1,6):
            boundary = index * band
            blend = (np.arange(2 * half) + .5) / (2 * half)
            row[boundary-half:boundary+half] = centers[index-1] * (1-blend) + centers[index] * blend
        value = np.tile(row, (height,1)) * 4
        if not np.array_equal(value, np.rint(value)):
            raise ValueError('Clean base must be exactly representable at native10bit')
        result.append(value.astype('<u2'))
    return result


def coordinates():
    return [(band+1,x,y) for band in range(6) for y in range(32,480,32)
            for x in (band*160+32,band*160+64,band*160+96)]


def generate(directory):
    if not directory.resolve().is_relative_to(ROOT):
        raise ValueError('Keep generated controls in task4 scratch')
    expected = W * H * 3 * (FRAMES+COUNT) * len(GAINS)
    if expected > SOURCE_CAP or shutil.disk_usage(ROOT).free < expected + (2 << 30):
        raise ValueError('Source budget or free-space check failed')
    directory.mkdir(parents=True, exist_ok=False)
    (directory/'README.md').write_text('Owner: Codex task4 amplitude diagnostic, 2026-10-05.\n'
        'Generated synthetic YUV420p10 only; no original media. Full96frame inputs and last32frame source tails are reproducible from the script/seed.\n'
        'Retain sources and receipts through interpretation; no encoding occurs during generate. Not a backup or release gate.\n')
    clean = bases(); coords = coordinates()
    zero = {plane:dict(max_detrended_sigma=0.0,max_hf_sigma=0.0) for plane in axes.PLANES}
    for _,x,y in coords:
        for index,plane in enumerate(axes.PLANES):
            f = 1 if index == 0 else 2
            m = axes.moments(clean[index][y//f:(y+32)//f,x//f:(x+32)//f]/4)
            zero[plane]['max_detrended_sigma'] = max(zero[plane]['max_detrended_sigma'],m['energy']**.5)
            zero[plane]['max_hf_sigma'] = max(zero[plane]['max_hf_sigma'],m['hf_energy']**.5)
    if any(v > 1e-10 for item in zero.values() for v in item.values()):
        raise ValueError('Known clean mask contains noise/gradient-edge spikes')
    header = f'YUV4MPEG2 W{W} H{H} F{RATE}:{SCALE} Ip A1:1 C420p10\n'.encode()
    rows, streams = [], []
    try:
        for gain in GAINS:
            folder = directory/label(gain); folder.mkdir()
            src, tail = folder/'source.y4m', folder/'source-tail.yuv'
            full = src.open('xb'); short = tail.open('xb'); full.write(header)
            streams.append((full,short,hashlib.sha256(header),hashlib.sha256()))
            rows.append(dict(gain=gain,source=str(src),tail=str(tail),frame_md5=[],
                source_pixels_by_band=[0]*8,min_code=[1023]*3,max_code=[0]*3))
        rng = np.random.default_rng(SEED)
        for frame in range(FRAMES):
            fields = []
            for base in clean:
                noise = np.clip(rng.standard_normal(base.shape),-3,3)
                noise -= noise.mean(); noise /= np.sqrt(np.mean(noise*noise))
                if np.max(np.abs(noise)) > 3.05:
                    raise ValueError('Unexpected normalized field bound')
                fields.append(noise)
            for row,(full,short,full_hash,tail_hash) in zip(rows,streams):
                planes = [np.rint(base.astype(np.float64) + 4*row['gain']*noise).astype('<u2')
                          for base,noise in zip(clean,fields)]
                for i,plane in enumerate(planes):
                    lo,hi = int(plane.min()),int(plane.max())
                    if lo < 64 or hi > (940 if i == 0 else 960):
                        raise ValueError('Source clipping/range confound')
                    row['min_code'][i] = min(row['min_code'][i],lo)
                    row['max_code'][i] = max(row['max_code'][i],hi)
                pixels = b''.join(p.tobytes() for p in planes)
                packet = b'FRAME\n'+pixels; full.write(packet); full_hash.update(packet)
                row['frame_md5'].append(hashlib.md5(pixels).hexdigest())
                if frame >= FIRST:
                    short.write(pixels); tail_hash.update(pixels)
                    if (frame-FIRST)%2 == 0:
                        row['source_pixels_by_band'] = (np.asarray(row['source_pixels_by_band'])+
                            np.bincount((planes[0].ravel()>>7).astype(np.int64),minlength=8)).tolist()
        for row,(full,short,full_hash,tail_hash) in zip(rows,streams):
            full.close(); short.close()
            row.update(source_sha256=full_hash.hexdigest(),tail_sha256=tail_hash.hexdigest(),
                source_stat=helper.identity(row['source']),tail_stat=helper.identity(row['tail']))
    finally:
        for full,short,_,_ in streams:
            full.close(); short.close()
    receipt = dict(schema='fgs-amplitude-control-source/1',seed=SEED,width=W,height=H,
        frames=FRAMES,first_scored_frame=FIRST,scored_frames=COUNT,fps=f'{RATE}/{SCALE}',
        source_bytes=sum(Path(r[k]).stat().st_size for r in rows for k in ('source','tail')),
        source_cap_bytes=SOURCE_CAP,zero_base_controls=zero,rows=rows,
        grain='Independent plane/frame clipped-Gaussian fields, demeaned and RMS-normalized; identical field reused across all gains before native10bit rounding',
        fixed_mask=dict(block_luma=32,block_chroma=16,coordinates=coords,
            rationale='Constant plateaus; >=16 luma /8 chroma pixel guard from affine transitions; image borders excluded'),
        interpretation='All planes vary together; overall-grain response only, not isolated chroma-policy causality')
    if receipt['source_bytes'] > SOURCE_CAP: raise ValueError('Actual sources exceed cap')
    helper.write(directory/'sources.json',receipt)
    return receipt


def ivf_pts(path):
    with Path(path).open('rb') as stream:
        h=stream.read(32)
        if len(h)!=32 or h[:4]!=b'DKIF' or h[8:12]!=b'AV01': raise ValueError('Wrong IVF')
        width,height,rate,scale,declared=struct.unpack_from('<HHIII',h,12)
        if (width,height)!=(W,H) or declared not in (0,FRAMES) or not rate or not scale: raise ValueError('Wrong IVF geometry/count')
        pts=[]
        while True:
            block=stream.read(12)
            if not block: break
            if len(block)!=12: raise ValueError('Truncated IVF header')
            size,timestamp=struct.unpack('<IQ',block)
            if not size or len(stream.read(size))!=size: raise ValueError('Truncated IVF payload')
            pts.append(Fraction(timestamp*scale,rate))
    expected=[Fraction(i*SCALE,RATE) for i in range(FRAMES)]
    if pts!=expected: raise ValueError('IVF does not preserve all96 known CFR frame indices')
    return pts


def run(directory,timeout):
    sources=json.loads((directory/'sources.json').read_text())
    if helper.hashes(BIN)['sha256']!=helper.PRODUCTION_SHA: raise ValueError('Wrong production binary')
    if shutil.disk_usage(ROOT).free < (2<<30): raise ValueError('Need2GiB free output headroom')
    ffmpeg=shutil.which('ffmpeg'); decoder=helper.hashes(ffmpeg)
    manifest=dict(schema=axes.SCHEMA,production_receipt=str(directory/'run-receipt.json'),
        production_binary_sha256=helper.PRODUCTION_SHA,ratio_floor_8bit=.25,windows=[])
    receipt=dict(complete=False,production_binary_sha256=helper.PRODUCTION_SHA,
        trace_enabled=False,plain_controls=False,runs=[])
    alignment_rows=[]
    try:
        for row in sources['rows']:
            folder=Path(row['source']).parent
            if helper.hashes(row['source'])['sha256']!=row['source_sha256'] or helper.hashes(row['tail'])['sha256']!=row['tail_sha256']:
                raise ValueError('Generated source differs from receipt')
            ivf=folder/'production.ivf'; table=folder/'grain.tbl'
            command=[str(BIN),'--timestamp-passthrough','-i',row['source'],'--frames',str(FRAMES),
                '--codec','av1','--output-depth','10','--qvbr','30']+CORE+[
                '--colormatrix','bt709','--colorprim','bt709','--transfer','bt709','--colorrange','limited',
                '--av1-film-grain','denoise=auto,chroma=auto,denoiser=bilateral',
                '--film-grain-table-out',str(table),'-o',str(ivf)]
            helper.write(folder/'encode-command.json',dict(argv=command,NVENC_TRACE_SUBMISSION=None))
            helper.run(command,folder/'encode.log',timeout,256<<20)
            counts=re.findall(r'encoded\s+(\d+)\s+frames',(folder/'encode.log').read_text(errors='replace'))
            if not counts or int(counts[-1])!=FRAMES: raise ValueError('Missing96frame completion')
            pts=ivf_pts(ivf); encoded=helper.hashes(ivf)
            commands={}
            for layer,grain in [('played',1),('base',0)]:
                commands[layer]=helper.ffmpeg_command(ffmpeg,ivf,FIRST,COUNT,grain,folder/(layer+'.yuv'))
                helper.run(commands[layer],folder/(layer+'-decode.log'),timeout,W*H*3*COUNT+(1<<20))
                if (folder/(layer+'.yuv')).stat().st_size!=W*H*3*COUNT: raise ValueError('Wrong decoded byte count')
                if helper.decode_pts(folder/(layer+'-decode.log'),COUNT)!=pts[FIRST:]: raise ValueError('Wrong actual decoder PTS')
            metadata=dict(schema='fgs-synthetic-known-frame-timeline/1',source_sha256=row['source_sha256'],
                generated_frame_ids=list(range(FIRST,FRAMES)),generated_frame_md5=row['frame_md5'][FIRST:],
                source_pts=[str(t) for t in pts[FIRST:]],production_ivf_sha256=encoded['sha256'],
                decoder_sha256=decoder['sha256'],encode_argv=command,decode_argv=commands,
                basis='Known generated96frame CFR sequence, byte-pinned input, exact IVF and dav1d displayed PTS/count. No claim of independent coarse pixel correspondence; static clean-frame correspondence is unidentifiable and immaterial to the invariant zero-source control.')
            helper.write(folder/'timeline.json',metadata)
            window=dict(id=label(row['gain']),title='fixed-synthetic-amplitude-control',content_class='synthetic-control',
                transfer='bt709',range='limited',qvbr=30,source_sha256=row['source_sha256'],width=W,height=H,
                frame_count=COUNT,sample_frames=list(range(COUNT)),active_rect=[0,0,W,H],active_rect_reviewed=True,
                active_rect_evidence=str(directory/'sources.json'),
                alignment=dict(metadata=str(folder/'timeline.json'),receipt=str(directory/'alignment.json')),
                source=dict(path=row['tail'],bits=10),played=dict(path=str(folder/'played.yuv'),bits=10),base=dict(path=str(folder/'base.yuv'),bits=10))
            manifest['windows'].append(window)
            alignment_rows.append(dict(id=window['id'],status='pass',basis=metadata['basis'],
                metadata_sha256=hashlib.sha256((folder/'timeline.json').read_bytes()).hexdigest(),
                raw_stats={k:axes.signature(window[k]['path']) for k in ('source','played','base')}))
            receipt['runs'].append(dict(gain=row['gain'],complete=True,encode_argv=command,ivf=encoded,
                decoder_sha256=decoder['sha256'],source_timeline=str(folder/'timeline.json')))
        helper.write(directory/'manifest.json',manifest)
        digest=hashlib.sha256((directory/'manifest.json').read_bytes()).hexdigest()
        helper.write(directory/'alignment.json',dict(schema='fgs-known-synthetic-timeline/1',manifest_sha256=digest,
            status='pass',natural_source_offset_test_applicable=False,windows=alignment_rows))
        selection=dict(schema=axes.SCHEMA,manifest_sha256=digest,review=dict(complete=True,
            receipt=str(directory/'sources.json'),excluded=[]),windows=[])
        for row,window in zip(sources['rows'],manifest['windows']):
            reader=axes.Raw(window['source'],W,H,COUNT)
            occupancy=np.zeros(8,dtype=np.int64)
            for frame in window['sample_frames']:
                occupancy+=np.histogram(reader.planes(frame)[0],axes.BANDS)[0]
            patches=[dict(frame=frame,x=x,y=y,band=band,masks=['core','expanded'])
                for frame in window['sample_frames'] for band,x,y in sources['fixed_mask']['coordinates']]
            selection['windows'].append(dict(id=window['id'],source_raw_stat=axes.signature(row['tail']),
                active_pixels_by_band=occupancy.tolist(),active_pixels=int(occupancy.sum()),
                patches=patches,all_grid_patches=len(patches),thresholds={},
                note='One fixed known-clean mask; core/expanded are identical aliases, not two independent tests'))
        helper.write(directory/'selection.json',selection)
        axes.score(directory/'manifest.json',directory/'selection.json',directory/'metrics.json')
        metrics=json.loads((directory/'metrics.json').read_text());curves=[]
        for plane in axes.PLANES:
            for band in range(1,7):
                points=[]
                for row,window in zip(sources['rows'],metrics['windows']):
                    cell=next(c for c in window['bands'] if c['mask']=='core' and c['plane']==plane and c['band']==[band*32,(band+1)*32])
                    points.append(dict(nominal_gain=row['gain'],layers=cell.get('layers'),error=cell.get('error')))
                positive=[p for p in points if p['layers'] and p['layers']['source']['amplitude_sigma_8bit']>=.25
                          and p['layers']['played']['amplitude_sigma_8bit']>0]
                x=np.log([p['layers']['source']['amplitude_sigma_8bit'] for p in positive])
                y=np.log([p['layers']['played']['amplitude_sigma_8bit'] for p in positive])
                beta=float(np.polyfit(x,y,1)[0]) if len(x)>=3 else None
                slopes=[]
                for a,b in zip(points,points[1:]):
                    if a['layers'] and b['layers']:
                        dx=b['layers']['source']['amplitude_sigma_8bit']-a['layers']['source']['amplitude_sigma_8bit']
                        slopes.append(dict(from_gain=a['nominal_gain'],to_gain=b['nominal_gain'],
                            local_gain=(b['layers']['played']['amplitude_sigma_8bit']-a['layers']['played']['amplitude_sigma_8bit'])/dx if dx else None))
                curves.append(dict(plane=plane,luma_band=[band*32,(band+1)*32],points=points,
                    local_gains=slopes,descriptive_positive_level_beta=beta,
                    caveat='Per-band descriptive response; inspect zero/base floors, censoring and grain size before interpreting exponent. No pooled library exponent or pixel-level confidence interval.'))
        helper.write(directory/'response-curves.json',dict(curves=curves,
            interpretation='Causal overall-grain amplitude control only; all planes vary together. Native chroma lag units; not library prevalence or isolated chroma-policy attribution.'))
        receipt['complete']=True
    finally:
        helper.write(directory/'run-receipt.json',receipt)


if __name__=='__main__':
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('mode',choices=('generate','run'))
    parser.add_argument('--directory',type=Path,default=DEFAULT)
    parser.add_argument('--timeout',type=int,default=900)
    args=parser.parse_args()
    if args.mode=='generate':
        result=generate(args.directory)
        print(json.dumps(dict(source_bytes=result['source_bytes'],source_cap_bytes=SOURCE_CAP,
            zero_base_controls=result['zero_base_controls'],gpu_jobs=0,original_media_reads=0)))
    else:
        run(args.directory,args.timeout)
