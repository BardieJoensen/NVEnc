#!/usr/bin/env python3
"""Render source-only mask evidence; never approve a review or read output layers."""
import argparse
import hashlib
import json
from pathlib import Path
import numpy as np
from PIL import Image,ImageDraw
import grain_axes as axes
import frame_safety as safety


def main():
    ap=argparse.ArgumentParser(description=__doc__);ap.add_argument('--manifest',type=Path,required=True);ap.add_argument('--selection',type=Path,required=True);ap.add_argument('--output',type=Path,required=True);args=ap.parse_args()
    manifest,digest,w=safety.load(args.manifest);selection=json.loads((args.selection/'selection.json').read_text())
    assert selection['manifest_sha256']==digest and selection['source_raw_stat']==axes.signature(w['source']['path'])
    masks_path=args.selection/'source-mask.npz';assert hashlib.sha256(masks_path.read_bytes()).hexdigest()==selection['proof_sha256']
    with np.load(masks_path) as z:proof={k:z[k] for k in z.files}
    args.output.mkdir(exist_ok=False)
    src=axes.Raw(w['source'],w['width'],w['height'],w['frame_count']);indices=sorted({0,w['frame_count']//2,w['frame_count']-1})
    rect=w['active_rect'];columns=rect[2]//32;pane_width=480;context_height=270;row_height=76
    canvas=Image.new('RGB',(pane_width*len(indices),context_height+70+8*row_height),(30,30,30));draw=ImageDraw.Draw(canvas)
    patches={};records=[]
    for col,frame in enumerate(indices):
        planes=src.planes(frame);left=col*pane_width
        # Direct code-value grayscale, solely for bounds/mask inspection; no metric uses this resized view.
        context=Image.fromarray(np.clip(planes[0],0,255).astype('u1'),'L').convert('RGB')
        context.thumbnail((pane_width,context_height),Image.Resampling.NEAREST);sx=context.width/w['width'];sy=context.height/w['height'];overlay=ImageDraw.Draw(context)
        for index,bits in enumerate(proof['mask'][frame]):
            if not bits:continue
            y,x=divmod(index,columns);x=rect[0]+32*x;y=rect[1]+32*y
            overlay.rectangle((round(x*sx),round(y*sy),round((x+32)*sx),round((y+32)*sy)),outline=(40,200,60) if bits&1 else (50,110,220),width=1)
        overlay.rectangle(tuple(round(v) for v in (rect[0]*sx,rect[1]*sy,(rect[0]+rect[2])*sx-1,(rect[1]+rect[3])*sy-1)),outline=(255,170,0),width=2)
        canvas.paste(context,(left,25));draw.text((left+5,5),f'{w["id"]} frame {frame} / {w["frame_count"]}',fill='white')
        draw.text((left+65,context_height+36),'core: Y / Cb / Cr      expanded-only: Y / Cb / Cr',fill='white')
        for band in range(8):
            top=context_height+65+band*row_height;draw.text((left+3,top+8),f'{band*32}-{(band+1)*32}',fill='white')
            for group in range(2):
                bits=proof['mask'][frame];eligible=((bits&1)!=0) if group==0 else (((bits&2)!=0)&((bits&1)==0))
                candidates=np.flatnonzero(eligible&(proof['band'][frame]==band))
                if not len(candidates):continue
                index=int(candidates[len(candidates)//2]);y,x=divmod(index,columns);x=rect[0]+32*x;y=rect[1]+32*y
                record=dict(frame=frame,band=[band*32,(band+1)*32],mask='core' if group==0 else 'expanded_only',block=index,x=x,y=y,eligible_patches=len(candidates),selection='middle row-major source-selected coordinate; no output/error inspection')
                for p,(plane,factor) in enumerate(zip(planes,(1,2,2))):
                    patch=plane[y//factor:(y+32)//factor,x//factor:(x+32)//factor].copy();key=f'f{frame}_b{band}_m{group}_{axes.PLANES[p]}';patches[key]=patch
                    # Native code grayscale for Y, 4x differences from neutral chroma for Cb/Cr inspection only.
                    display=patch if p==0 else 128+(patch-128)*4
                    tile=Image.fromarray(np.clip(display,0,255).astype('u1'),'L').resize((58,58),Image.Resampling.NEAREST).convert('RGB');canvas.paste(tile,(left+65+group*198+p*62,top))
                records.append(record)
    image_path=args.output/'source-masks.png';canvas.save(image_path)
    np.savez_compressed(args.output/'native-source-patches.npz',**patches)
    report=dict(schema='fgs-source-mask-proof/1',manifest_sha256=digest,mask_sha256=selection['proof_sha256'],source_stat=axes.signature(w['source']['path']),frames=indices,active_rect=rect,
        figure_sha256=hashlib.sha256(image_path.read_bytes()).hexdigest(),patch_archive_sha256=hashlib.sha256((args.output/'native-source-patches.npz').read_bytes()).hexdigest(),records=records,
        review_complete=False,view_only='Context/Y use native 8-bit-equivalent code grayscale, chroma uses4x deviations from128; nearest-neighbor magnification. No display conversion enters measurements. Green=core,blue=expanded-only,orange=reviewed active rectangle. Exact source patches retained as float32 code/2^(bits-8), lossless for supported depths.')
    with (args.output/'proof.json').open('x') as f:json.dump(report,f,indent=2);f.write('\n')

if __name__=='__main__':main()
