"""Extract the already identified event from a production encode starting at zero."""
from pathlib import Path
from fractions import Fraction
import copy,json,shutil,subprocess,sys
import numpy as np
import heldout_measurement as held
import prepare_instrumentation_windows as native

root=Path(__file__).resolve().parent
old=root/'heldout-windows-capture2/knightfall-p10'
parent=root/'knightfall-full-history-confirmation';folder=parent/'event';folder.mkdir()
assert held.raw_usage(root)+(1920*1080*3*16*3)<held.RAW_BUDGET
h=held.identity_helper();ivf=parent/'video.ivf';parsed=h.inspect_ivf(ivf,11760)
metadata=json.loads((old/'extraction-metadata.json').read_text())
source_pts=[Fraction(v) for v in metadata['frame_pts']['source'][145:161]]
all_pts=[Fraction(v*parsed['scale'],parsed['rate']) for v in parsed['timestamps']]
start=min(range(len(all_pts)),key=lambda i:abs(all_pts[i]-source_pts[0]));pts=all_pts[start:start+16]
assert len(pts)==16 and max(abs(a-b) for a,b in zip(pts,source_pts))<Fraction(11,10000)
data=np.load(old/'event-witness/native-event-frames.npz')
with (folder/'source.yuv').open('xb') as f:
    for i in range(145,161):
        for plane in ('Y','Cb','Cr'):f.write(data[f'source_{i}_{plane}'].astype('<u2').tobytes())
commands={}
for layer,grain in [('played',1),('base',0)]:
    command=native.ffmpeg_command(shutil.which('ffmpeg'),ivf,start,16,grain,folder/(layer+'.yuv'));commands[layer]=command
    native.run(command,folder/(layer+'-decode.log'),300,1920*1080*3*16+(1<<20))
    assert native.decode_pts(folder/(layer+'-decode.log'),16)==pts
digest=native.hashes(ivf)['sha256']
metadata.update(played_bitstream_sha256=digest,base_bitstream_sha256=digest,played_decode_argv=commands['played'],base_decode_argv=commands['base'],
    source_minus_output_pts=str(source_pts[0]-pts[0]),frame_pts={'source':list(map(str,source_pts)),'played':list(map(str,pts)),'base':list(map(str,pts))},
    context_frames=start,evaluation_frames=16,source_subset={'retained_native_archive':str(old/'event-witness/native-event-frames.npz'),'original_evaluation_frames':list(range(145,161))},
    full_history_encode_command=json.loads((parent/'command.json').read_text()))
native.write(folder/'extraction-metadata.json',metadata)
manifest=json.loads((old/'manifest.reviewed.json').read_text());w=manifest['windows'][0];w.update(id='knightfall-full-history-event',frame_count=16,sample_frames=list(range(16)),alignment={'metadata':str(folder/'extraction-metadata.json'),'receipt':str(folder/'alignment.json')})
for layer in ('source','played','base'):w[layer]['path']=str(folder/(layer+'.yuv'))
manifest['production_receipt']=str(parent/'scope.json');native.write(folder/'manifest.reviewed.json',manifest)
for command in ([sys.executable,str(root/'align_native_windows.py'),'--manifest',str(folder/'manifest.reviewed.json'),'--output',str(folder/'alignment.json')],
                [sys.executable,str(root/'frame_safety.py'),'select','--manifest',str(folder/'manifest.reviewed.json'),'--output',str(folder/'selection')],
                [sys.executable,str(root/'render_source_mask_proof.py'),'--manifest',str(folder/'manifest.reviewed.json'),'--selection',str(folder/'selection'),'--output',str(folder/'source-proof')]):subprocess.run(command,check=True)
native.write(folder/'execution-receipt.json',{'complete':True,'full_history_frames':11760,'event_start_frame':start,'event_count':16,'ivf':parsed,'ivf_sha256':digest,'owned_raw_files':{name:native.hashes(folder/(name+'.yuv'))|{'path':str(folder/(name+'.yuv'))} for name in ('source','played','base')}})
print('SOURCE MASK REVIEW REQUIRED: '+str(folder/'source-proof/source-masks.png'))
