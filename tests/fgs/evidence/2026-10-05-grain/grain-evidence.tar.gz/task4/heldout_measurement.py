#!/usr/bin/env python3
"""Sequential held-out diagnostic adapter. Default preparation opens metadata only.

extract opens one explicitly selected private original and uses the GPU; parent
releases execution after task3. Source/patch review and scoring remain explicit.
No library, service, API, discovery or automatic raw deletion operations exist.
"""
import argparse
from collections import defaultdict
import fcntl
from fractions import Fraction
import hashlib
import importlib.util
import json
import math
import os
from pathlib import Path
import re
import shutil
import signal
import sys
import time

import prepare_instrumentation_windows as native

HERE = Path(__file__).resolve().parent
ROOT = HERE.parent
OLD = Path('/tmp/downloads/codex-work/fgs-improvement-20261004')
IDENTITY = OLD/'repeat_identity.py'
IDENTITY_SHA = '6bbe9c681be59bda776915af28df4c9e23683583573785e16ccfef5ac9a967ad'
FILMGRAIN = OLD/'baseline-pin/tests/fgs/filmgrn.py'
FLOW = Path('/opt/docker-apps/configs/tdarr-flow/flows/AV1NVENCflow1.json')
COPY_RECEIPTS = (ROOT/'heldout-originals/receipt.json', ROOT/'heldout-animation-originals/receipt.json')
RAW_BUDGET = 12 << 30

def sha(path): return hashlib.sha256(Path(path).read_bytes()).hexdigest()

def module(path, name):
    spec = importlib.util.spec_from_file_location(name, path)
    result = importlib.util.module_from_spec(spec); spec.loader.exec_module(result)
    return result

def identity_helper():
    if sha(IDENTITY) != IDENTITY_SHA: raise ValueError('Identity helper changed')
    return module(IDENTITY, 'heldout_identity')

def source_stat(path):
    s = Path(path).stat()
    return dict(bytes=s.st_size,mtime_ns=s.st_mtime_ns,ctime_ns=s.st_ctime_ns,
                inode=s.st_ino,device=s.st_dev,nlink=s.st_nlink)

def validate_window(w):
    if not re.fullmatch('[a-z0-9_-]+', w['id']): raise ValueError('Unsafe window id')
    if not w['original_source'] or w['output_depth'] != 10 or w['source_bits'] != 8:
        raise ValueError('Require original native 8-bit source and 10-bit output')
    if w['input_args'] != ['--avhw','--timestamp-passthrough','--video-track','1']:
        raise ValueError('Unexpected hardware-decode/timestamp flags')
    if w['fgs'] != 'denoise=auto,chroma=auto,denoiser=bilateral': raise ValueError('Unexpected FGS')
    expected_qvbr = {'animation':34,'live-action':30}.get(w['content_class'])
    if w['qvbr'] != expected_qvbr: raise ValueError('Unexpected production content-class QVBR')
    period = math.ceil(12*Fraction(w['fps']))
    if w['context_frames'] != period or w['evaluation_frames'] != period or w['frames'] != 2*period:
        raise ValueError('Require exactly the declared 12-second context and evaluation counts')
    if not 24 <= w['evaluation_frames'] <= 720 or w['seek'] < 0:
        raise ValueError('Out-of-bounds window')
    width,height=w['width'],w['height']
    if width%2 or height%2 or not 32<=width<=4096 or not 32<=height<=2160:
        raise ValueError('Invalid native geometry')
    each=width*height*3*w['evaluation_frames']
    if each>4*(1<<30) or each*3>RAW_BUDGET: raise ValueError('Raw window exceeds fixed cap')
    return each

def prepare(plan_path, expected_sha, output_root):
    if sha(plan_path) != expected_sha: raise ValueError('Frozen held-out plan hash mismatch')
    plan=json.loads(Path(plan_path).read_text())
    if plan['schema']!='fgs-heldout-windows/1' or not plan['frozen_source_only_selection']:
        raise ValueError('Require frozen source-only held-out plan')
    if plan['production_binary_sha256']!=native.PRODUCTION_SHA:
        raise ValueError('Only deployed c6 production binary is permitted')
    grouped=defaultdict(list)
    for w in plan['windows']: grouped[w['source_title']].append(w['selection_fraction'])
    if (len(plan['windows'])!=15 or len({w['id'] for w in plan['windows']})!=15
        or len(grouped)!=5 or any(sorted(v)!=[.1,.4,.7] for v in grouped.values())):
        raise ValueError('Require the frozen five-title, three-window source selection')
    output_root=Path(output_root).resolve()
    if output_root.parent!=HERE: raise ValueError('Output root must be a direct child of task4')
    h=identity_helper(); ffmpeg=shutil.which('ffmpeg')
    if not ffmpeg: raise ValueError('ffmpeg required')
    pins={}
    for path in COPY_RECEIPTS:
        receipt=json.loads(path.read_text())
        if not receipt['complete']: raise ValueError('Private original-copy receipt is incomplete')
        for copy in receipt['copies']:
            if copy['complete']:
                pins[copy['path']]={'copy':copy,'receipt':str(path),'receipt_sha256':sha(path)}
    windows=[]
    for w in plan['windows']:
        expected=validate_window(w); pin=pins.get(w['path'])
        if not pin or pin['copy']['sha256']!=w['sha256'] or pin['copy']['destination_stat']!=w['source_stat']:
            raise ValueError('Source SHA/stat is not bound to a completed independent private copy')
        if w['source_stat']['nlink']!=1: raise ValueError('Private originals must not be hard-linked')
        if w['color_args']!=h.COLOR or w['metadata_args']!=[]:
            raise ValueError('Unexpected colour or metadata arguments')
        folder=output_root/w['id']; ivf=folder/'video.ivf'; table=folder/'grain.tbl'
        arm={'prefix':[],'binary':plan['production_binary']}
        encode=h.encode_argv(w,arm,'av1',ivf,table)
        source=[plan['production_binary']]+w['input_args']+['--allow-other-negative-pts',
                '--seek',str(w['seek']),'-i',w['path'],'--frames',str(w['frames']),
                '--codec','raw','--output-depth','10']+w['color_args']+[
                '--output-format','y4m','--y4m-timestamp','-o','-']
        entry={'id':w['id'],'item':w,'source_copy_receipt':pin['receipt'],
               'source_copy_receipt_sha256':pin['receipt_sha256'],'folder':str(folder),
               'ivf':str(ivf),'table':str(table),'encode_command':encode,'source_command':source,
               'start':w['context_frames'],'count':w['evaluation_frames'],
               'raw_bytes_each':expected,'raw_bytes_total':expected*3,
               'source_raw':str(folder/'source.yuv'),'played_raw':str(folder/'played.yuv'),
               'base_raw':str(folder/'base.yuv')}
        for name,grain in [('played',1),('base',0)]:
            entry[name+'_command']=native.ffmpeg_command(ffmpeg,ivf,entry['start'],entry['count'],grain,entry[name+'_raw'])
        windows.append(entry)
    dependencies=[Path(__file__).resolve(),Path(native.__file__).resolve(),IDENTITY,FILMGRAIN,
                  HERE/'align_native_windows.py',HERE/'grain_axes.py',HERE/'frame_safety.py']
    dependencies+=sorted({Path(w['active_rect_evidence']) for w in plan['windows']
                         if w.get('active_rect_reviewed') and w.get('active_rect_evidence')})
    return dict(schema='fgs-heldout-measurement-commands/1',heldout_plan=str(Path(plan_path).resolve()),
        heldout_plan_sha256=expected_sha,output_root=str(output_root),production_binary=plan['production_binary'],
        production_binary_sha256=native.PRODUCTION_SHA,flow_sha256=plan['flow_sha256'],
        dependencies={str(p):sha(p) for p in dependencies},windows=windows,
        raw_budget_bytes=RAW_BUDGET,execution='one explicitly selected window at a time; trace disabled',
        source_pin_policy='Complete private-copy SHA receipt plus exact unchanged destination stat/mode before and after; no repeated whole-original hash',
        raw_retention='Keep all three owned raw files pending reviewed alignment, source-mask proof, metrics and parent cleanup release; this adapter never deletes raw files')

def validate_execution(config):
    if sha(config['heldout_plan'])!=config['heldout_plan_sha256']: raise ValueError('Held-out plan changed')
    for path,digest in config['dependencies'].items():
        if sha(path)!=digest: raise ValueError('Pinned helper changed: '+path)
    if sha(FLOW)!=config['flow_sha256']: raise ValueError('Production flow changed')
    binary=native.hashes(config['production_binary'])
    if binary['sha256']!=native.PRODUCTION_SHA:
        raise ValueError('Production binary changed')
    return binary

def validate_source(entry):
    w=entry['item']; path=Path(w['path'])
    if sha(entry['source_copy_receipt'])!=entry['source_copy_receipt_sha256']:
        raise ValueError('Source-copy receipt changed')
    if source_stat(path)!=w['source_stat'] or (path.stat().st_mode & 0o777)!=0o400:
        raise ValueError('Private source identity, link count or read-only mode changed')

def raw_usage(root):
    return sum(p.stat().st_size for name in ('source.yuv','played.yuv','base.yuv')
               for p in Path(root).rglob(name))

def followup_commands(folder):
    manifest=folder/'manifest.reviewed.json'
    return {'active_picture_review_required':str(folder/'manifest.pending-review.json'),
        'align':[sys.executable,str(HERE/'align_native_windows.py'),'--manifest',str(manifest),'--output',str(folder/'alignment.json')],
        'select':[sys.executable,str(HERE/'frame_safety.py'),'select','--manifest',str(manifest),'--output',str(folder/'selection')],
        'selection_review_required':str(folder/'selection/selection.json'),
        'score':[sys.executable,str(HERE/'frame_safety.py'),'score','--manifest',str(manifest),
                 '--selection',str(folder/'selection'),'--output',str(folder/'metrics')],
        'raw_cleanup':'No automatic cleanup. Parent reviews metrics/source-mask proof, preserves representative source patches, then explicitly releases only this window’s three owned raw files.'}

def extract(config, window_id, timeout):
    binary=validate_execution(config)
    entries=[w for w in config['windows'] if w['id']==window_id]
    if len(entries)!=1: raise ValueError('Select exactly one frozen window id')
    entry=entries[0]; w=entry['item']; validate_source(entry)
    root=Path(config['output_root']); folder=Path(entry['folder'])
    if root.parent!=HERE or folder.parent!=root: raise ValueError('Output escaped declared task4 root')
    if raw_usage(HERE)+entry['raw_bytes_total']>RAW_BUDGET:
        raise ValueError('Retained raw windows fill 12GiB budget; parent must review and release previous owned raw first')
    if shutil.disk_usage(ROOT).free < entry['raw_bytes_total']+(4<<30):
        raise ValueError('Insufficient scratch space including 4GiB headroom')
    root.mkdir(exist_ok=True); folder.mkdir(exist_ok=False)
    native.write(folder/'commands.json',entry)
    result={'schema':'fgs-heldout-measurement-execution/1','id':window_id,'complete':False,
            'production_binary_sha256':native.PRODUCTION_SHA,'trace_enabled':False,
            'production_binary':binary,'encoder_environment':{k:os.environ.get(k) for k in
                ('CUDA_VISIBLE_DEVICES','CUDA_LAUNCH_BLOCKING','CUDA_DEVICE_MAX_CONNECTIONS','CUDA_MODULE_LOADING')},
            'heldout_plan_sha256':config['heldout_plan_sha256'],'source_pin':w['source_stat'],
            'source_sha256':w['sha256'],'source_copy_receipt':entry['source_copy_receipt'],
            'stage':'encoding','started_utc':time.strftime('%Y-%m-%dT%H:%M:%SZ',time.gmtime())}
    previous={sig:signal.getsignal(sig) for sig in (signal.SIGTERM,signal.SIGINT)}
    def interrupted(sig,frame):
        for number in previous: signal.signal(number,signal.SIG_IGN)
        raise KeyboardInterrupt(f'Signal {sig}; stop owned process group')
    for sig in previous: signal.signal(sig,interrupted)
    try:
        h=identity_helper()
        native.run(entry['encode_command'],folder/'encode.log',timeout,512<<20)
        encoded=h.inspect_ivf(entry['ivf'],w['frames'])
        if any(b<=a for a,b in zip(encoded['timestamps'],encoded['timestamps'][1:])):
            raise ValueError('IVF display timestamps are not strictly increasing')
        log=(folder/'encode.log').read_text(errors='replace')
        matches=re.findall(r'encoded\s+(\d+)\s+frames',log)
        if not matches or int(matches[-1])!=w['frames']: raise ValueError('Wrong encoded count in log')
        if (encoded['width'],encoded['height'])!=(w['width'],w['height']) or Fraction(encoded['rate'],encoded['scale'])!=Fraction(w['fps']):
            raise ValueError('Encoded geometry/cadence differs from frozen source metadata')
        filmgrn=module(FILMGRAIN,'heldout_filmgrn'); entries=filmgrn.load(entry['table'])
        ivf_hash=native.hashes(entry['ivf']); table_hash=native.hashes(entry['table'])
        if not entries: raise ValueError('Filmgrn1 table has no entries')
        validate_source(entry)
        result.update(stage='extracting',ivf=encoded,ivf_hash=ivf_hash,table_hash=table_hash,table_entries=len(entries))
        native.write(folder/'encoded.json',dict(result,encode_command=entry['encode_command']))
        native_window=dict(entry,encoded=encoded)
        source_pts=native.decode_source(native_window,timeout)
        if Path(entry['source_raw']).stat().st_size!=entry['raw_bytes_each']: raise ValueError('Wrong source raw size')
        validate_source(entry)
        decoder=native.hashes(entry['played_command'][0])
        for name in ('played','base'):
            native.run(entry[name+'_command'],folder/(name+'-decode.log'),timeout,entry['raw_bytes_each']+(1<<20))
            if Path(entry[name+'_raw']).stat().st_size!=entry['raw_bytes_each']: raise ValueError('Wrong native output byte count')
        on=native.decode_pts(folder/'played-decode.log',entry['count']); off=native.decode_pts(folder/'base-decode.log',entry['count'])
        start,count=entry['start'],entry['count']
        packet_pts=[Fraction(v*encoded['scale'],encoded['rate']) for v in encoded['timestamps'][start:start+count]]
        if on!=off or on!=packet_pts: raise ValueError('Decoded PTS differ from strict IVF display mapping')
        offset=source_pts[0]-on[0]; period=Fraction(encoded['scale'],encoded['rate'])
        if abs(offset)>period/2+Fraction(1,1000): raise ValueError('Source/IVF origin discrepancy exceeds half a frame')
        if max(abs(s-p-offset) for s,p in zip(source_pts,on))>Fraction(11,10000):
            raise ValueError('Source/output PTS mapping is not constant within 1.1ms')
        metadata=dict(schema='fgs-native-window-extraction/1',production_binary_sha256=native.PRODUCTION_SHA,
            source_original_sha256=w['sha256'],played_bitstream_sha256=ivf_hash['sha256'],base_bitstream_sha256=ivf_hash['sha256'],
            decoder_binary_sha256=decoder['sha256'],source_decode_argv=entry['source_command'],
            played_decode_argv=entry['played_command'],base_decode_argv=entry['base_command'],
            pts_extraction_receipt=str(folder/'source-display-pts.json'),source_minus_output_pts=str(offset),
            pts_tolerance_seconds='11/10000',frame_pts={k:[str(x) for x in pts] for k,pts in
                [('source',source_pts),('played',on),('base',off)]},
            context_frames=start,evaluation_frames=count,source_probe_metadata_from_frozen_plan=w)
        native.write(folder/'extraction-metadata.json',metadata)
        metric_window=dict(id=w['id'],title=w['title'],content_class=w['content_class'],transfer=w['transfer'],range=w['range'],
            qvbr=w['qvbr'],source_sha256=w['sha256'],width=w['width'],height=w['height'],frame_count=count,
            sample_frames=list(range(count)),active_rect=w.get('active_rect',[0,0,w['width'],w['height']]),
            active_rect_reviewed=w.get('active_rect_reviewed',False),active_rect_evidence=w.get('active_rect_evidence'),
            alignment=dict(metadata=str(folder/'extraction-metadata.json'),receipt=str(folder/'alignment.json')),
            source=dict(path=entry['source_raw'],bits=10),played=dict(path=entry['played_raw'],bits=10),base=dict(path=entry['base_raw'],bits=10))
        native.write(folder/'manifest.pending-review.json',dict(schema='fgs-grain-axes/1',production_receipt=str(folder/'encoded.json'),
            production_binary_sha256=native.PRODUCTION_SHA,ratio_floor_8bit=.25,windows=[metric_window]))
        native.write(folder/'next-commands.json',followup_commands(folder))
        result['owned_raw_files']={name:native.hashes(entry[name+'_raw'])|{'path':entry[name+'_raw']} for name in ('source','played','base')}
        validate_source(entry)
        if native.identity(entry['ivf'])!=ivf_hash['stat']: raise ValueError('IVF changed during extraction')
        if native.identity(entry['table'])!=table_hash['stat']: raise ValueError('Filmgrn1 table changed during extraction')
        if native.identity(entry['played_command'][0])!=decoder['stat']: raise ValueError('Decoder binary changed during extraction')
        if native.identity(config['production_binary'])!=binary['stat']: raise ValueError('Production binary changed during extraction')
        result.update(complete=True,stage='pending_source_and_alignment_review',raw_bytes=entry['raw_bytes_total'],
                      source_identity_verified_before_after=True,raw_deleted=False)
    except BaseException as exc:
        result['error']=repr(exc)
        raise
    finally:
        for sig,handler in previous.items(): signal.signal(sig,handler)
        try:
            validate_source(entry)
            result['source_identity_verified_after']=True
        except Exception as exc:
            result.update(complete=False,source_identity_verified_after=False,source_final_check_error=repr(exc))
        result['finished_utc']=time.strftime('%Y-%m-%dT%H:%M:%SZ',time.gmtime())
        native.write(folder/'execution-receipt.json',result)
    if not result['complete']: raise ValueError('Final identity check failed; see execution receipt')
    print(json.dumps({'window':window_id,'receipt':str(folder/'execution-receipt.json'),'next':str(folder/'next-commands.json')}))

def main():
    parser=argparse.ArgumentParser(description=__doc__)
    sub=parser.add_subparsers(dest='mode',required=True)
    p=sub.add_parser('prepare',help='Metadata/commands only; no source or GPU reads')
    p.add_argument('--plan',type=Path,required=True); p.add_argument('--plan-sha256',required=True)
    p.add_argument('--output-root',type=Path,required=True); p.add_argument('--commands',type=Path,required=True)
    p=sub.add_parser('extract',help='One original/GPU window; only after parent execution release')
    p.add_argument('--commands',type=Path,required=True); p.add_argument('--commands-sha256',required=True)
    p.add_argument('--window',required=True); p.add_argument('--timeout',type=int,default=900)
    args=parser.parse_args()
    if args.mode=='prepare':
        config=prepare(args.plan,args.plan_sha256,args.output_root);native.write(args.commands,config)
        print(json.dumps({'commands':str(args.commands),'sha256':sha(args.commands),'windows':len(config['windows']),'media_opened':False}))
    else:
        if not 30<=args.timeout<=1800: raise ValueError('Command timeout must be 30..1800s')
        if sha(args.commands)!=args.commands_sha256: raise ValueError('Reviewed command-plan SHA mismatch')
        with (HERE/'.heldout-measurement.lock').open('a') as lock:
            fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB)
            extract(json.loads(args.commands.read_text()),args.window,args.timeout)

if __name__=='__main__': main()
