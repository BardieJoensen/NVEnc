#!/usr/bin/env python3
"""Validate existing short raw windows; no decode, encode, GPU or media search.

Use extraction metadata with actual decoder PTS and exact invocation receipts.
A manually set alignment_verified flag is deliberately not accepted.
"""
import argparse
from fractions import Fraction
import hashlib
import json
from pathlib import Path
import re

import numpy as np
import grain_axes as axes


def normalized_grain_decode(argv):
    args = list(argv)
    if args.count("-filmgrain") != 1 or args.count("-c:v") != 1:
        raise ValueError("require explicit -c:v libdav1d and -filmgrain for both decodes")
    if args[args.index("-c:v") + 1] != "libdav1d":
        raise ValueError("require the same dav1d decoder")
    grain = args[args.index("-filmgrain") + 1]
    args[args.index("-filmgrain") + 1] = "FILMGRAIN"
    args[-1] = "OUTPUT"
    return grain, args


def verify_metadata(window, manifest):
    blob = Path(window["alignment"]["metadata"]).read_bytes()
    m = json.loads(blob)
    if m.get("schema") != "fgs-native-window-extraction/1":
        raise ValueError("missing extraction metadata schema")
    for key in ("production_binary_sha256", "played_bitstream_sha256", "base_bitstream_sha256", "decoder_binary_sha256"):
        if not re.fullmatch("[0-9a-f]{64}", m.get(key, "")):
            raise ValueError("missing hash binding: " + key)
    if m["production_binary_sha256"] != manifest["production_binary_sha256"]:
        raise ValueError("extraction is not bound to the requested production binary")
    if m["source_original_sha256"] != window["source_sha256"]:
        raise ValueError("wrong original source hash")
    if m["played_bitstream_sha256"] != m["base_bitstream_sha256"]:
        raise ValueError("grain-on/off must decode the same bitstream")
    if (Path(m["played_decode_argv"][-1]).resolve() != Path(window["played"]["path"]).resolve()
        or Path(m["base_decode_argv"][-1]).resolve() != Path(window["base"]["path"]).resolve()):
        raise ValueError("decode commands must bind the actual raw output paths")
    if window["played"]["bits"] != window["base"]["bits"]:
        raise ValueError("same decoder invocations must use identical on/off native depths")
    on, on_args = normalized_grain_decode(m["played_decode_argv"])
    off, off_args = normalized_grain_decode(m["base_decode_argv"])
    if on != "1" or off != "0" or on_args != off_args:
        raise ValueError("on/off invocation must differ only in filmgrain and output path")
    if not m.get("source_decode_argv") or not m.get("pts_extraction_receipt"):
        raise ValueError("source decode command and actual PTS extraction receipt required")
    pts = {name: [Fraction(value) for value in m["frame_pts"][name]]
           for name in ("source", "played", "base")}
    count = window["frame_count"]
    if any(len(v) != count for v in pts.values()):
        raise ValueError("PTS arrays must have exactly the raw frame count")
    if any(any(b <= a for a, b in zip(v, v[1:])) for v in pts.values()):
        raise ValueError("PTS must be strictly increasing, with no duplicate/dropped frame mapping")
    offset = Fraction(m["source_minus_output_pts"])
    tolerance = Fraction(m.get("pts_tolerance_seconds", "1/1000"))
    minimum_spacing = min(b - a for v in pts.values() for a, b in zip(v, v[1:]))
    if tolerance < 0 or tolerance >= minimum_spacing / 10:
        raise ValueError("PTS tolerance must be less than one tenth of one frame")
    errors = [abs(s - (p + offset)) for s, p in zip(pts["source"], pts["played"])]
    errors += [abs(a - b) for a, b in zip(pts["played"], pts["base"])]
    if max(errors) > tolerance:
        raise ValueError("timestamp mapping differs beyond declared sub-frame tolerance")
    return {"metadata_sha256": hashlib.sha256(blob).hexdigest(),
            "max_pts_error_seconds": float(max(errors)),
            "pts_tolerance_seconds": float(tolerance),
            "same_bitstream_sha256": m["played_bitstream_sha256"],
            "production_binary_sha256": m["production_binary_sha256"],
            "source_decode_argv": m["source_decode_argv"],
            "pts_extraction_receipt": m["pts_extraction_receipt"]}


def coarse_luma(reader, frame, rect):
    x, y, width, height = rect
    a = reader.planes(frame)[0][y:y + height, x:x + width]
    rows, columns = height // 16, width // 16
    return a[:rows * 16, :columns * 16].reshape(rows, 16, columns, 16).mean(axis=(1, 3))


def run(manifest_path, output):
    manifest, digest = axes.load_manifest(manifest_path)
    reports = []
    for w in manifest["windows"]:
        if Path(w["alignment"]["receipt"]).resolve() != Path(output).resolve():
            raise ValueError("manifest alignment receipt must name this output")
        report = {"id": w["id"], **verify_metadata(w, manifest)}
        raw = {name: axes.Raw(w[name], w["width"], w["height"], w["frame_count"])
               for name in ("source", "played", "base", "raw_base") if name in w}
        report["raw_stats"] = {n: axes.signature(r.path) for n, r in raw.items()}
        count = w["frame_count"]
        radius = min(2, (count - 1) // 2)
        reference = [coarse_luma(raw["source"], f, w["active_rect"]) for f in range(count)]
        base = [coarse_luma(raw["base"], f, w["active_rect"]) for f in range(count)]
        common = range(radius, count - radius)
        errors = {offset: [float(np.mean((reference[f] - base[f + offset])**2)) for f in common]
                  for offset in range(-radius, radius + 1)}
        mean_errors = {k: float(np.mean(v)) for k, v in errors.items()}
        zero = mean_errors[0]
        alternative = min(value for offset, value in mean_errors.items() if offset != 0)
        margin = (alternative - zero) / max(alternative, 1e-12)
        # This is an ambiguity screen, not an optimized image-quality target.
        # Static/tied scenes remain inconclusive even if timestamps match.
        status = "pass" if alternative - zero > 1e-4 and margin > 0.02 else "inconclusive"
        report.update(status=status, common_frames=list(common),
            coarse_native_luma_mse_by_offset=mean_errors,
            coarse_native_luma_mse_per_frame=errors,
            zero_offset_advantage_fraction=margin,
            interpretation="timestamps/counts and coarse source/base offset controls agree" if status == "pass" else
                "offset control is ambiguous or favors another frame; inspect mapping or obtain independent trace evidence before scoring")
        reports.append(report)
    axes.dump(output, {"schema": "fgs-native-window-alignment/1", "manifest_sha256": digest,
        "status": "pass" if all(r["status"] == "pass" for r in reports) else "inconclusive",
        "windows": reports})


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--manifest", required=True)
    parser.add_argument("--output", required=True)
    args = parser.parse_args()
    run(args.manifest, args.output)
