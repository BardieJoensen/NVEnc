"""Summarize the frozen held-out census, without selected confirmation events."""
from pathlib import Path
import collections, hashlib, json, math

ROOT = Path(__file__).resolve().parent
PLANES = ('Y', 'Cb', 'Cr')

def sha(p):
    return hashlib.file_digest(p.open('rb'), 'sha256').hexdigest()

def axes(window, plane):
    rows = [b for b in window['bands'] if b['mask']=='core' and b['plane']==plane and b.get('occupancy_weighted_axes')]
    weight = sum(b['mean_measured_band_occupancy'] for b in rows)
    out = {'measured_occupancy':weight, 'layers':{}}
    for layer in ('source','played','base','added'):
        d={}
        for key in ('amplitude_sigma_8bit','hf_sigma_8bit'):
            d[key]=math.sqrt(sum(b['mean_measured_band_occupancy']*b['occupancy_weighted_axes'][layer][key]**2 for b in rows)/weight) if weight else None
        d['acf']={}
        for lag in ('h1','h2','v1','v2'):
            eligible=[b for b in rows if b['occupancy_weighted_axes'][layer]['acf'][lag] is not None]
            den=sum(b['mean_measured_band_occupancy'] for b in eligible)
            d['acf'][lag]=sum(b['mean_measured_band_occupancy']*b['occupancy_weighted_axes'][layer]['acf'][lag] for b in eligible)/den if den else None
        out['layers'][layer]=d
    return out

windows=[]
for title in ('knightfall','marshals','homegrown','insidious','toy_story_5'):
    for point in ('p10','p40','p70'):
        ident=title+'-'+point
        folder=ROOT/('heldout-windows-capture2' if ident=='knightfall-p10' else 'heldout-windows-capture3')/ident
        census_path=ROOT/(ident+'-census.json')
        w=json.loads(census_path.read_text())['windows'][0]
        manifest=json.loads((folder/'manifest.reviewed.json').read_text())['windows'][0]
        cpath=folder/'constant-patches-v2/summary.json'
        if not cpath.exists(): cpath=folder/'constant-patches/summary.json'
        c=json.loads(cpath.read_text())
        assert c['complete'] and c['frames']==w['frames']
        assert c.get('schema')=='fgs-constant-patch-safety/2' or all(v['changed_pixels']==0 for v in c['counts'].values())
        constant={}
        for plane in PLANES:
            v=dict(c['counts']['all_active_grid:'+plane])
            plane_pixels=manifest['active_rect'][2]*manifest['active_rect'][3]/(1 if plane=='Y' else 4)
            patch_pixels=1024 if plane=='Y' else 256
            v['positive_patch_area_time_fraction']=v['positive_patch_frames']*patch_pixels/(plane_pixels*w['frames'])
            v['changed_pixel_area_time_fraction']=v['changed_pixels']/(plane_pixels*w['frames'])
            constant[plane]=v
        bands=collections.defaultdict(lambda: {'positive_patch_frames':0,'changed_pixels':0,'frames':set()})
        union=set()
        for line in (cpath.parent/'per-frame.jsonl').read_text().splitlines():
            row=json.loads(line)
            for b in row['bands']:
                if b['mask']!='all_active_grid' or not b['positive_patches']:continue
                key=(b['plane'],tuple(b['band']));v=bands[key]
                v['positive_patch_frames']+=b['positive_patches'];v['changed_pixels']+=b['changed_pixels'];v['frames'].add(row['frame']);union.add(row['frame'])
        bandrows=[{'plane':p,'luma_band':list(b),**{k:(len(vv) if k=='frames' else vv) for k,vv in v.items()}} for (p,b),v in sorted(bands.items())]
        windows.append({'id':ident,'title':title,'frames':w['frames'],'constant':constant,'constant_positive_union_frames':len(union),'constant_positive_bands':bandrows,'max_examples':c['max_examples'],'band_incidence':[v for v in w['per_plane_incidence'] if v['mask']=='core'],'axes':{p:axes(w,p) for p in PLANES},'pins':{'census':str(census_path),'census_sha256':sha(census_path),'constant':str(cpath),'constant_sha256':sha(cpath)}})

titles=[]
for title in dict.fromkeys(w['title'] for w in windows):
    rows=[w for w in windows if w['title']==title]
    item={'title':title,'frames':sum(w['frames'] for w in rows),'constant_positive_union_frames':sum(w['constant_positive_union_frames'] for w in rows),'planes':{}}
    for plane in PLANES:
        vals=[w['constant'][plane] for w in rows]
        d={k:sum(v[k] for v in vals) for k in ('frames_with_constant_patches','frames_with_added_grain_on_constant_source','constant_patch_frames','positive_patch_frames','changed_pixels')}
        d['max_added_rms_8bit']=max(v['max_added_rms_8bit'] for v in vals)
        d['positive_patch_area_time_fraction']=sum(w['constant'][plane]['positive_patch_area_time_fraction']*w['frames'] for w in rows)/item['frames']
        item['planes'][plane]=d
    titles.append(item)

report={'schema':'fgs-heldout-census-aggregate/1','evaluation_frames':sum(w['frames'] for w in windows),'titles':titles,'windows':windows,'limits':'Frozen fifteen-window sample, not a probability sample of library titles or frames; selected full-history confirmations excluded. Any affected frame means at least one patch, not whole-frame excess. Exact constant-source check excludes clipping-only correction. Spatial axes include source texture; ACF pooled here is descriptive occupancy-weighted per-band ACF, not a covariance estimator; per-band values remain in pinned census files. No invented genre weighting.'}
out=ROOT/'heldout-census-summary.json'
with out.open('x') as f: json.dump(report,f,indent=2,allow_nan=False);f.write('\n')
print(json.dumps({'frames':report['evaluation_frames'],'titles':titles},indent=2))
