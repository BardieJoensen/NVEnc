#!/bin/bash
set -euo pipefail
git config --global --add safe.directory /work
apt-get update -qq
DEBIAN_FRONTEND=noninteractive apt-get install -y -qq libass-dev=1:0.17.1-2build1 libx11-dev=2:1.8.7-1build1 libplacebo-dev=6.338.2-2build1
export PATH=/usr/local/cuda/bin:$PATH
meson setup --reconfigure build-gate . --buildtype=release -Denable_vmaf=disabled -Denable_libvship=disabled
ninja -C build-gate -j 4
dpkg-query -W libass-dev libx11-dev libplacebo-dev
