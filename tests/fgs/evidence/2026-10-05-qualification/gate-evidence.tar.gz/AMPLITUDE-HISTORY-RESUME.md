# Reuse completed full-history amplitude witnesses

The original negative encode finished 183,661 frames with exit 0, but ANSI colour escapes immediately before `encoded` prevented the old completion regex from matching. The old failed status, log and video remain unchanged. `amplitude_history_support.py` is a pinned copy of the original runner with only ANSI removal before that same regex. `resume_amplitude_history.py` verifies completed histories and runs only the missing authorized arm; generation alone never counts as a passing amplitude/full gate.

The authorized `histories` invocation independently hashes the exact private source and historical binary, binds the original complete command/runtime/source stat, then performs a fresh strict full `ffprobe -err_detect explode -count_frames` decode and stable hash of the existing negative. Its new report points to the unchanged video. It next encodes the plain reference from the same full source with the historical binary and exact settings, removing only `--av1-film-grain`, and requires exit 0, 183,661 encoded/decoded frames, expected AV1 geometry/format, blank probe error output and stable output hash. No candidate runs in this mode.

Once both history reports are complete and the root supplies the final candidate SHA/core, run:

```bash
python3 /tmp/downloads/codex-work/fgs-submission-20261005/resume_amplitude_history.py candidate \
  --source /tmp/downloads/codex-work/fgs-submission-20261005/original-fixtures/play-dirty-source.mkv \
  --negative-report /tmp/downloads/codex-work/fgs-submission-20261005/amplitude-histories-resumed/negative/report.json \
  --reference-report /tmp/downloads/codex-work/fgs-submission-20261005/amplitude-histories-resumed/reference/report.json \
  --candidate FINAL_PINNED_BINARY --candidate-sha256 FINAL_FULL_SHA256 --candidate-core FINAL_FULL_CORE \
  --output /tmp/downloads/codex-work/fgs-submission-20261005/amplitude-final-candidate
```

The output directory must be new. Candidate mode rechecks source and historical binary SHA/stat, full exact argv, successful encoded/strict-probe counts and formats, original probe evidence, current output stat and full output SHA before accepting either reused history. It records report/probe/output bindings in `reused-histories.json`, then runs the candidate using the pinned shared encode function, with submission/FGS tracing disabled. The unchanged gate-compatible `amplitude-manifest.json` is written last, linking the two reused histories, new candidate and the established city/dialogue witness windows. Gate thresholds and stage semantics are unchanged; the actual full gate still must run.

All new paths are under the task's SSD scratch, with a 40 GiB free-space preflight and per-run budget. The helper never overwrites a prior output, original receipt, library media or source. Its own encoder child is the only process it may terminate. Preserve the source, old negative video and both new run directories through qualification because the manifest intentionally references those existing histories.
