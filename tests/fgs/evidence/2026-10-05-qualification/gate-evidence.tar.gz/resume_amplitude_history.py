#!/usr/bin/env python3
"""Verify/reuse full-history arms and generate only the missing authorized arm.

histories: verify completed legacy negative, then encode historical plain reference.
candidate: validate both completed histories, encode only explicitly pinned candidate.
No existing output/receipt is modified; generation is not a gate pass.
"""
import argparse
import hashlib
import json
import os
from pathlib import Path
import re
import shutil
import signal
import sys

import amplitude_history_support as h

SUPPORT_SHA='872ba8f735edb66576674db99dab9481b83f325b1a547ee5335beec7e6a8b1e1'
SOURCE=h.TASK/'original-fixtures/play-dirty-source.mkv'
PROBE_FIELDS='stream=codec_name,width,height,pix_fmt,avg_frame_rate,r_frame_rate,nb_read_frames,start_time,color_range,color_space,color_transfer,color_primaries:format=duration,size'


def read(path): return json.loads(Path(path).read_text())


def probe_command(target):
    return ['ffprobe','-v','error','-err_detect','explode','-threads','2','-select_streams','v:0',
            '-count_frames','-show_entries',PROBE_FIELDS,'-of','json',str(target)]


def validate_metadata(metadata):
    streams=metadata.get('streams',[])
    h.require(len(streams)==1,'Exactly one measured video stream required')
    v=streams[0]
    h.require(v.get('codec_name')=='av1' and v.get('width')==1920 and v.get('height')==800
        and v.get('pix_fmt')=='yuv420p10le' and v.get('nb_read_frames')==str(h.FRAMES),
        'Exact full-history video format/count required')


def encoded_count(log):
    text=re.sub(r'\x1b\[[0-?]*[ -/]*[@-~]','',Path(log).read_text(errors='replace'))
    counts=re.findall(r'\bencoded\s+(\d+)\s+frames\b',text)
    h.require(counts and counts[-1]==str(h.FRAMES),'Exact encoded completion count required')
    return int(counts[-1])


def verify_legacy_negative(legacy,root,source_pin,negative_pin,env):
    legacy=legacy.resolve(strict=True)
    h.require(legacy.is_relative_to(h.TASK),'Legacy evidence must be in task scratch')
    command=read(legacy/'command.json');runtime=read(legacy/'runtime.json')
    target=(legacy/'video.mkv').resolve(strict=True)
    expected=[str(h.NEGATIVE),*h.encoder_arguments(SOURCE,target,False)]
    h.require(command==expected and runtime['command']==expected,'Negative original command mismatch')
    h.require(runtime.get('returncode')==0 and runtime.get('finished_at'),'Negative encode unfinished')
    h.require(runtime.get('encoder_sha256')==h.NEGATIVE_SHA,'Negative encoder pin differs')
    h.require(runtime.get('source_stat_before')==source_pin['stat'],'Negative source stat differs')
    ids=read(legacy.parent/'encoder-identities.json')
    h.require(ids['negative']==negative_pin,'Historical binary identity differs')
    old_source=read(legacy.parent/'source-copy.json')['copy']
    h.require(old_source==source_pin,'Historical source copy pin differs')
    frames=encoded_count(legacy/'encode.log')
    arm=root/'negative';arm.mkdir()
    for name in ('command.json','runtime.json','encode.log'):
        (arm/name).write_bytes((legacy/name).read_bytes())
    before=h.signature(target)
    probe=h.checked_command(probe_command(target),arm,'ffprobe',timeout=h.TIMEOUT,env=env)
    h.require(not probe.stderr.strip(),'Negative strict full-decode probe errors')
    h.require(h.signature(target)==before,'Negative changed during full decode')
    metadata=json.loads(probe.stdout);validate_metadata(metadata)
    identity=h.stable_hash(target)
    h.require(identity['stat']==before,'Negative changed after full decode')
    report=dict(label='negative',complete=True,command=command,runtime=runtime,
        source_sha256=h.SOURCE_SHA,encoder_sha256=h.NEGATIVE_SHA,encoded_frames=frames,
        ffprobe=metadata,**identity,verification_dir=str(arm),
        legacy_evidence=str(legacy),legacy_failed_status_preserved=True,
        parser_correction='ANSI sequences removed before the unchanged encoded-frame regex')
    h.write_json(arm/'report.json',report)
    return report


def reuse_arm(report_path,label,source_pin,negative_pin):
    report_path=report_path.resolve(strict=True)
    h.require(report_path.is_relative_to(h.TASK),'Arm report must be in task scratch')
    r=read(report_path);arm=report_path.parent;target=Path(r['path']).resolve(strict=True)
    h.require(target.is_relative_to(h.TASK),'Arm output must be in task scratch')
    command=[str(h.NEGATIVE),*h.encoder_arguments(SOURCE,target,label=='reference')]
    h.require(r.get('complete') is True and r.get('label')==label,'Arm not finalized')
    h.require(r.get('source_sha256')==h.SOURCE_SHA and r.get('encoder_sha256')==h.NEGATIVE_SHA,'Arm identity differs')
    h.require(r.get('encoded_frames')==h.FRAMES and encoded_count(arm/'encode.log')==h.FRAMES,'Incomplete encoded history')
    h.require(r['command']==command and read(arm/'command.json')==command,'Arm command differs')
    runtime=read(arm/'runtime.json')
    h.require(runtime==r['runtime'] and runtime.get('command')==command and runtime.get('returncode')==0 and runtime.get('finished_at'),'Runtime incomplete/different')
    h.require(runtime.get('source_stat_before')==source_pin['stat'] and runtime.get('encoder_sha256')==negative_pin['sha256'],'Runtime pins differ')
    validate_metadata(r['ffprobe'])
    h.require(read(arm/'ffprobe.stdout')==r['ffprobe'] and not (arm/'ffprobe.stderr').read_text().strip(),'Probe evidence differs/errors')
    pc=probe_command(target);pr=read(arm/'ffprobe-runtime.json')
    h.require(read(arm/'ffprobe-command.json')==pc and pr.get('argv')==pc and pr.get('returncode')==0 and pr.get('finished_at'),'Full strict decode receipt missing')
    h.require(h.signature(target)==r['stat'],'Output stat changed since full decode')
    identity=h.stable_hash(target,r['sha256']);h.require(identity['stat']==r['stat'],'Output changed during reuse verification')
    return r,dict(report=str(report_path),report_sha256=h.sha256(report_path),
        output=identity,command=command,strict_full_decode_frames=h.FRAMES,
        probe_runtime_sha256=h.sha256(arm/'ffprobe-runtime.json'))


def main():
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('mode',choices=('histories','candidate'))
    p.add_argument('--source',required=True,type=Path)
    p.add_argument('--output',required=True,type=Path)
    p.add_argument('--legacy-negative',type=Path)
    p.add_argument('--negative-report',type=Path)
    p.add_argument('--reference-report',type=Path)
    p.add_argument('--candidate',type=Path)
    p.add_argument('--candidate-sha256')
    p.add_argument('--candidate-core')
    a=p.parse_args()
    h.require(h.sha256(Path(h.__file__))==SUPPORT_SHA,'Pinned encoding support changed')
    h.require(a.source.resolve(strict=True)==SOURCE.resolve(strict=True),'Exact verified private source required')
    root=a.output.absolute();h.require(root.parent.resolve()==h.TASK.resolve(),'New output must be directly below task scratch')
    h.require(not root.exists() and not root.is_symlink(),'Output already exists')
    h.require(shutil.disk_usage(h.TASK).free>=h.BUDGET,'Need40GiB free scratch')
    if a.mode=='histories': h.require(a.legacy_negative is not None,'Legacy negative evidence required')
    else:
        h.require(a.negative_report and a.reference_report and a.candidate,'Both history reports and candidate required')
        h.require(re.fullmatch('[0-9a-f]{64}',a.candidate_sha256 or '') and re.fullmatch('[0-9a-f]{40}',a.candidate_core or ''),'Explicit full candidate SHA/core required')
        a.candidate=a.candidate.resolve(strict=True)
        h.require(a.candidate.is_relative_to(h.TASK),'Candidate must be task-pinned')
    root.mkdir(mode=0o700);signal.signal(signal.SIGTERM,h.interrupted)
    status=dict(started_at=h.now(),complete=False,stage='preflight',mode=a.mode,generation_only=True,
        amplitude_gate_passed=False,local_full_gate_passed=False,candidate_core=a.candidate_core,candidate_sha256=a.candidate_sha256)
    try:
        h.write_json(root/'status.json',status)
        (root/'README.md').write_text('Owned Codex full-history amplitude resume. Existing histories are immutable external references. New reference/candidate output only. Preserve reports/source and linked histories through qualification; scratch is not backup. Generation is not a gate pass.\n')
        for script in (Path(__file__),Path(h.__file__)): (root/script.name).write_bytes(script.read_bytes())
        (root/'tmp').mkdir();env=os.environ.copy();env.update(TMPDIR=str(root/'tmp'),CUDA_CACHE_PATH=str(root/'cuda-cache'),PYTHONDONTWRITEBYTECODE='1')
        env.pop('NVENC_TRACE_SUBMISSION',None)
        for key in list(env):
            if key.startswith('NVENC_FGS_') and 'TRACE' in key: del env[key]
        _,source_pin=h.copy_source(SOURCE,root);negative_pin=h.stable_hash(h.NEGATIVE,h.NEGATIVE_SHA)
        h.checked_command(['ffprobe','-version'],root,'ffprobe-version',env=env)
        results={};reuse={}
        if a.mode=='histories':
            status.update(stage='verifying_completed_negative');h.write_json(root/'status.json',status)
            results['negative']=verify_legacy_negative(a.legacy_negative,root,source_pin,negative_pin,env)
            for suffix,cmd in [('version',[str(h.NEGATIVE),'--version']),('ldd',['ldd',str(h.NEGATIVE)])]:
                got=h.checked_command(cmd,root,'negative-'+suffix,env=env)
                h.require('not found' not in got.stdout,'Historical runtime dependency missing')
            status.update(stage='encoding_reference');h.write_json(root/'status.json',status)
            results['reference']=h.encode(h.NEGATIVE,h.NEGATIVE_SHA,SOURCE,source_pin['stat'],root,'reference',True,env)
        else:
            for label,path in [('negative',a.negative_report),('reference',a.reference_report)]:
                results[label],reuse[label]=reuse_arm(path,label,source_pin,negative_pin)
            h.write_json(root/'reused-histories.json',reuse)
            h.stable_hash(a.candidate,a.candidate_sha256)
            for suffix,cmd in [('version',[str(a.candidate),'--version']),('ldd',['ldd',str(a.candidate)])]:
                got=h.checked_command(cmd,root,'candidate-'+suffix,env=env)
                h.require('not found' not in got.stdout,'Candidate runtime dependency missing')
            status.update(stage='encoding_candidate');h.write_json(root/'status.json',status)
            results['candidate']=h.encode(a.candidate,a.candidate_sha256,SOURCE,source_pin['stat'],root,'candidate',False,env)
        h.require(h.signature(SOURCE)==source_pin['stat'],'Private source changed')
        for label,result in results.items(): h.require(h.signature(Path(result['path']))==result['stat'],label+' finalized output changed')
        status.update(stage='complete',complete=True,finished_at=h.now(),results=results,storage=h.check_budget(root))
        h.write_json(root/'status.json',status)
        if a.mode=='candidate':
            manifest={'source':dict(path=str(SOURCE),sha256=h.SOURCE_SHA)}
            for label,r in results.items(): manifest[label]=dict(path=r['path'],sha256=r['sha256'],encoder_sha256=r['encoder_sha256'])
            manifest['reference']['mode']='Same full source/settings and historical encoder; only --av1-film-grain removed'
            manifest['provenance']=dict(candidate_core=a.candidate_core,expected_frames=h.FRAMES,complete_history=True,
                source_copy_receipt=str(root/'source-copy.json'),reused_histories_receipt=str(root/'reused-histories.json'),
                witness_windows={'city':{'seconds':856.333,'frames':12},'dialogue':{'seconds':5727.583,'frames':12}},
                preparation_only=True,amplitude_gate_passed=False,local_full_gate_passed=False)
            h.write_json(root/'amplitude-manifest.json',manifest)
        print(str(root/'status.json'),flush=True)
    except BaseException as error:
        status.update(stage='failed',complete=False,finished_at=h.now(),error=repr(error));h.write_json(root/'status.json',status);raise


if __name__=='__main__':
    try: main()
    except (Exception,KeyboardInterrupt) as error:
        print('Amplitude resume failed: '+repr(error),file=sys.stderr);sys.exit(2)
